# v0.0.14 (Wed Apr 13 2022)

#### 🐛 Bug Fix

- Update dependency net.logstash.logback:logstash-logback-encoder to v7.1.1 [#94](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/94) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))

#### Authors: 1

- [@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot])

---

# v0.0.13 (Fri Apr 08 2022)

#### ⚠️ Pushed to `master`

- Update default purpose ([@wweston](https://github.intuit.com/wweston))

#### Authors: 1

- wweston ([@wweston](https://github.intuit.com/wweston))

---

# v0.0.12 (Fri Apr 08 2022)

#### 🐛 Bug Fix

- Update all non-major dependencies Docker tags [#93](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/93) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))

#### ⚠️ Pushed to `master`

- Update renovate.json ([@wweston](https://github.intuit.com/wweston))

#### Authors: 2

- [@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot])
- wweston ([@wweston](https://github.intuit.com/wweston))

---

# v0.0.11 (Wed Apr 06 2022)

#### 🐛 Bug Fix

- Update all non-major dependencies [#90](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/90) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))

#### Authors: 1

- [@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot])

---

# v0.0.10 (Tue Apr 05 2022)

#### ⚠️ Pushed to `master`

- Fix exception response from IUS ([@wweston](https://github.intuit.com/wweston))

#### Authors: 1

- wweston ([@wweston](https://github.intuit.com/wweston))

---

# v0.0.9 (Tue Apr 05 2022)

#### ⚠️ Pushed to `master`

- Add queued exception case ([@wweston](https://github.intuit.com/wweston))

#### Authors: 1

- wweston ([@wweston](https://github.intuit.com/wweston))

---

# v0.0.8 (Mon Apr 04 2022)

#### ⚠️ Pushed to `master`

- Remove Unknown conditional skipRelease ([@wweston](https://github.intuit.com/wweston))
- Get email from user account and enable notification ([@wweston](https://github.intuit.com/wweston))

#### Authors: 1

- wweston ([@wweston](https://github.intuit.com/wweston))

---

# v0.0.7 (Fri Apr 01 2022)

#### 🐛 Bug Fix

- Update dependency org.springframework.boot:spring-boot-maven-plugin to v2.6.6 [#91](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/91) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))
- Update dependency com.intuit.data.process:eventbus-kafka to v1.7.4 [#89](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/89) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))
- Update dependency com.intuit.platform.jsk:jsk-bom to v2.11.1 [#92](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/92) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))

#### Authors: 1

- [@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot])

---

# v0.0.6 (Thu Mar 31 2022)

#### ⚠️ Pushed to `master`

- Update Jenkinsfile ([@wweston](https://github.intuit.com/wweston))

#### Authors: 1

- wweston ([@wweston](https://github.intuit.com/wweston))

---

# v0.0.5 (Thu Mar 31 2022)



---

# v0.0.4 (Thu Mar 31 2022)



---

# v0.0.3 (Thu Mar 31 2022)



---

# v0.0.2 (Thu Mar 31 2022)



---

# v0.0.1 (Thu Mar 31 2022)

#### 🐛 Bug Fix

- Update dependency com.github.spotbugs:spotbugs-maven-plugin to v4.6.0.0 [#88](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/88) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))
- Update dependency org.springframework.boot:spring-boot-maven-plugin to v2.6.5 [#87](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/87) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))
- Update all non-major dependencies Docker tags [#86](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/86) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))
- Update API models [#85](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/85) ([@wweston](https://github.intuit.com/wweston))
- Update all non-major dependencies Docker tags [#84](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/84) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))
- Update dependency org.apache.maven.plugins:maven-compiler-plugin to v3.10.1 [#82](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/82) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))
- Update all non-major dependencies [#81](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/81) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))
- Update dependency com.intuit.data.process:eventbus-kafka to v1.7.3 [#80](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/80) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))
- MSaaS PR: Add/Update Environments [#78](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/78) (svcdoaadmin [@wweston](https://github.intuit.com/wweston))
- Update dependency org.sonarsource.java:sonar-jacoco-listeners to v5 [#77](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/77) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))
- Update dependency io.gatling:gatling-maven-plugin to v4 [#75](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/75) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))
- Update dependency org.apache.maven.plugins:maven-resources-plugin to v3 [#76](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/76) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))
- Update dependency org.springframework.boot:spring-boot-maven-plugin to v2.6.3 [#73](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/73) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))
- Update all non-major dependencies [#72](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/72) ([@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot]))
- Migrate from Docker/CPD1 to Podman/CPD2 [#68](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/68) (root@test-q0rrm-gr9pn [@mnagireddy](https://github.intuit.com/mnagireddy) svcdoaadmin)
- Merge branch 'master' into develop ([@ywang22](https://github.intuit.com/ywang22))
- [PPEENG-581](https://jira.intuit.com/browse/PPEENG-581): add missing stage ([@ywang22](https://github.intuit.com/ywang22))
- MSaaS PR: Add/Update Environments [#66](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/66) (MSaaSServiceAccount@intuit.com [@svc-sbseg-ci](https://github.intuit.com/svc-sbseg-ci))
- Eks [#65](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/65) (yihao_wang@intuit.com [@kdammalapat](https://github.intuit.com/kdammalapat) MSaaSServiceAccount@intuit.com [@ywang22](https://github.intuit.com/ywang22))
- Replace keystore.jks that has EXPIRING cert (May 6th, 2021!) [#62](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/62) (appuser@platform-asset-manager-appd-deployment-557cc75d87-pc2vl [@svc-msaas-updater](https://github.intuit.com/svc-msaas-updater))
- Automsok 2021 02 25 19 39 06 [#61](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/61) (yihao_wang@intuit.com [@kdammalapat](https://github.intuit.com/kdammalapat) MSaaSServiceAccount@intuit.com [@ywang22](https://github.intuit.com/ywang22))
- Cron IT and other fixes [#57](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/57) (Kautilya_Dammalapati@intuit.com [@kdammalapat](https://github.intuit.com/kdammalapat))
- IT for external service calls [#56](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/56) (Kautilya_Dammalapati@intuit.com [@kdammalapat](https://github.intuit.com/kdammalapat))
- Integration tests for multiple personas and invalid state change exce… [#55](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/55) (Kautilya_Dammalapati@intuit.com [@kdammalapat](https://github.intuit.com/kdammalapat))
- Idpgdpr 2463 [#54](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/54) (Kautilya_Dammalapati@intuit.com [@kdammalapat](https://github.intuit.com/kdammalapat))
- event bus config update [#53](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/53) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- eventbus config update [#52](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/52) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- fix typo ([@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- merge develop [#51](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/51) ([@skrishnan2](https://github.intuit.com/skrishnan2) Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy) [@kdammalapat](https://github.intuit.com/kdammalapat))
- msaas update [#50](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/50) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- prd config update [#48](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/48) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- Qal event bus config update [#47](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/47) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- Fixing Cron code to remove unwanted code [#46](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/46) (Kautilya_Dammalapati@intuit.com [@kdammalapat](https://github.intuit.com/kdammalapat))
- LegalHold Changes [#43](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/43) (Kautilya_Dammalapati@intuit.com [@kdammalapat](https://github.intuit.com/kdammalapat))
- updated jenkins file and event bus prd config [#41](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/41) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- code cov limit update & jenkins change [#38](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/38) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- Code changes for bug fix [#37](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/37) ([@skrishnan2](https://github.intuit.com/skrishnan2))
- Code changes for Increasing code coverage [#36](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/36) ([@skrishnan2](https://github.intuit.com/skrishnan2))
- Unused code clean up [#35](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/35) (Prema_Kuppuswamy@intuit.com [@kdammalapat](https://github.intuit.com/kdammalapat))
- Filter query api [#34](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/34) ([@skrishnan2](https://github.intuit.com/skrishnan2))
- Filter query api [#33](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/33) (Sabari_Krishnan@intuit.com [@skrishnan2](https://github.intuit.com/skrishnan2) [@pkuppuswamy](https://github.intuit.com/pkuppuswamy) [@kdammalapat](https://github.intuit.com/kdammalapat))
- Develop [#32](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/32) (Sabari_Krishnan@intuit.com [@kdammalapat](https://github.intuit.com/kdammalapat) [@pkuppuswamy](https://github.intuit.com/pkuppuswamy) [@skrishnan2](https://github.intuit.com/skrishnan2))
- fix unit test [#31](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/31) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- InProgress and Compression Recoverable Actions with cron scheduler [#30](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/30) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- Tests fix for Access State Machine [#29](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/29) (Kautilya_Dammalapati@intuit.com [@kdammalapat](https://github.intuit.com/kdammalapat))
- Develop [#28](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/28) ([@skrishnan2](https://github.intuit.com/skrishnan2) Sabari_Krishnan@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy) [@kdammalapat](https://github.intuit.com/kdammalapat))
- Idpgdpr2383 [#21](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/21) (Kautilya_Dammalapati@intuit.com [@kdammalapat](https://github.intuit.com/kdammalapat))
- Pending Recoverable Action for access WO [#27](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/27) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- Queued Recoverable Action for Access WO [#26](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/26) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- build fix and more unit tests [#25](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/25) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- Unit test for Reminder/cron/scheduler Job [#24](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/24) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- disable metrics in msaas config [#23](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/23) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- update validate WO & add few more tests [#22](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/22) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- jenkins file update & added few more unti tests [#20](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/20) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- Unit test cases added [#18](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/18) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- remove application properties [#17](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/17) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- config branch update [#16](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/16) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- ICIMS and WIDS Api Integration with unit tests [#15](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/15) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- Code changes for filterBy APIs [#14](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/14) ([@skrishnan2](https://github.intuit.com/skrishnan2))
- Compression Status API and reminder jobs [#11](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/11) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- WorkOrderItemEvent with service Impl & graphql mutation [#9](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/9) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- Initial code for GraphQL dependencies [#3](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/3) ([@skrishnan2](https://github.intuit.com/skrishnan2) [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- test [#7](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/7) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- enabled state transitions [#6](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/6) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- State Machine code [#1](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/1) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy) [@kdammalapat](https://github.intuit.com/kdammalapat))
- Service Impl and event bus changes [#4](https://github.intuit.com/datagovern-compliance/dg-orch-worker/pull/4) (Prema_Kuppuswamy@intuit.com [@pkuppuswamy](https://github.intuit.com/pkuppuswamy))

#### ⚠️ Pushed to `master`

- Fix Jenkinsfile ([@wweston](https://github.intuit.com/wweston))
- Add create release ([@wweston](https://github.intuit.com/wweston))
- Enable auto ([@wweston](https://github.intuit.com/wweston))
- Add jaeger configs ([@wweston](https://github.intuit.com/wweston))
- Metrics and callback cleanup ([@wweston](https://github.intuit.com/wweston))
- Add justification for spotbugs suppression ([@wweston](https://github.intuit.com/wweston))
- Commit temp tests for stg and prd ([@wweston](https://github.intuit.com/wweston))
- Remove karate test from stg ([@wweston](https://github.intuit.com/wweston))
- Update eventbus policy ids ([@wweston](https://github.intuit.com/wweston))
- Fix PMD Error ([@wweston](https://github.intuit.com/wweston))
- Enable deploy to prd ([@wweston](https://github.intuit.com/wweston))
- Update IDPS namespace ([@wweston](https://github.intuit.com/wweston))
- Add user logging ([@wweston](https://github.intuit.com/wweston))
- Add more logging ([@wweston](https://github.intuit.com/wweston))
- Configure state machine scheduler ([@wweston](https://github.intuit.com/wweston))
- Use object serializer for kakfa serialization ([@wweston](https://github.intuit.com/wweston))
- Log exceptions ([@wweston](https://github.intuit.com/wweston))
- Fix for duplicate child workflows ([@wweston](https://github.intuit.com/wweston))
- Fix eventbus SSL ([@wweston](https://github.intuit.com/wweston))
- Use correct eventbus in qal ([@wweston](https://github.intuit.com/wweston))
- Update worker to use java sdk ([@wweston](https://github.intuit.com/wweston))
- Use correct state action for DM callback ([@wweston](https://github.intuit.com/wweston))
- Notify pending job ([@wweston](https://github.intuit.com/wweston))
- Temporary fix for startup issue ([@wweston](https://github.intuit.com/wweston))
- Implementation of job callback ([@wweston](https://github.intuit.com/wweston))
- Inital ICIMS implementation ([@wweston](https://github.intuit.com/wweston))
- Inital integration with WIDS ([@wweston](https://github.intuit.com/wweston))
- Fix startup ([@wweston](https://github.intuit.com/wweston))
- Integrate with OINP ([@wweston](https://github.intuit.com/wweston))
- Add offline ticket config ([@wweston](https://github.intuit.com/wweston))
- Inital implemenation of OINP ([@wweston](https://github.intuit.com/wweston))
- Increase code coverage ([@wweston](https://github.intuit.com/wweston))
- Fix queries ([@wweston](https://github.intuit.com/wweston))
- Fixup api to use job terminology ([@wweston](https://github.intuit.com/wweston))
- Fix dependency cycle ([@wweston](https://github.intuit.com/wweston))
- Avoid using version in docker image name ([@wweston](https://github.intuit.com/wweston))
- Increase test coverage ([@wweston](https://github.intuit.com/wweston))
- Set preprod only ([@wweston](https://github.intuit.com/wweston))
- Update jenkinsfile ([@wweston](https://github.intuit.com/wweston))
- Remove mesh from configs ([@wweston](https://github.intuit.com/wweston))
- Update stg bootstrap ([@wweston](https://github.intuit.com/wweston))
- Add stg bootstrap ([@wweston](https://github.intuit.com/wweston))
- Revert .autorc changes ([@wweston](https://github.intuit.com/wweston))
- Update Jenkinsfile ([@mnagireddy](https://github.intuit.com/mnagireddy))
- Update Dockerfile.sonar ([@wweston](https://github.intuit.com/wweston))
- Implement statemachine poc ([@wweston](https://github.intuit.com/wweston))
- Major refresh ([@wweston](https://github.intuit.com/wweston))
- Initial commit (svcdoaadmin)

#### Authors: 13

- [@kdammalapat](https://github.intuit.com/kdammalapat)
- [@renovate-pro[bot]](https://github.intuit.com/renovate-pro[bot])
- [@ywang22](https://github.intuit.com/ywang22)
- appuser (appuser@platform-asset-manager-appd-deployment-557cc75d87-pc2vl)
- mnagireddy ([@mnagireddy](https://github.intuit.com/mnagireddy))
- MSaaSServiceAccount (MSaaSServiceAccount@intuit.com)
- pkuppuswamy ([@pkuppuswamy](https://github.intuit.com/pkuppuswamy))
- root (root@test-q0rrm-gr9pn)
- skrishnan2 ([@skrishnan2](https://github.intuit.com/skrishnan2))
- svc-msaas-updater ([@svc-msaas-updater](https://github.intuit.com/svc-msaas-updater))
- svc-sbseg-ci ([@svc-sbseg-ci](https://github.intuit.com/svc-sbseg-ci))
- svcdoaadmin ([@svcdoaadmin](https://github.intuit.com/svcdoaadmin))
- wweston ([@wweston](https://github.intuit.com/wweston))
