package com.intuit.dgorchworkerapp.service;

import com.intuit.dgorchworkerapp.data.models.DataEntityDetails;
import com.intuit.dgorchworkerapp.data.models.DataManagerConfig;
import com.intuit.dgorchworkerapp.data.models.DataStoreDetails;
import com.intuit.dgorchworkerapp.data.models.ExtEngagementDetails;
import com.intuit.dgorchworkerapp.data.models.ManagedType;
import com.intuit.dgorchworkerapp.data.models.OnboardStage;
import com.intuit.dgorchworkerapp.repository.DataManagerRepository;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Unit test case for the Service layer.
 */
@ExtendWith(MockitoExtension.class)
public class DataManagerServiceTest {

  private final List<ManagedType> managedTypeList = new ArrayList<>();
  private final List<DataStoreDetails> storeDetailsList = new ArrayList<>();
  private final List<DataEntityDetails> entityDetailsList = new ArrayList<>();
  private final List<ExtEngagementDetails> extEngagementDetailsList = new ArrayList<>();
  private final Timestamp timestamp = new Timestamp(System.currentTimeMillis());

  @Mock private DataManagerRepository dataManagerRepository;
  @InjectMocks DataManagerService dataManagerService;

  /**
   * Unit test case for the testGetByAssetId method.
   */
  @Test
  public void testGetByAssetId() {

    final ManagedType managedType = ManagedType.builder()
            .assetId(11)
            .managedTypeId(11)
            .managedTypeValue("INTERNAL")
            .createdDate(timestamp)
            .deletedDate(null)
            .build();

    managedTypeList.add(managedType);

    final DataStoreDetails dataStoreDetails =
            DataStoreDetails.builder()
                    .assetId(11)
                    .dataStoreId(11)
                    .dataStoreValue("dataStoreTest")
                    .createdDate(timestamp)
                    .deletedDate(null)
                    .build();

    storeDetailsList.add(dataStoreDetails);

    final DataEntityDetails dataEntityDetails =
            DataEntityDetails.builder()
                    .assetId(11)
                    .dataEntityId(11)
                    .dataEntityValue("dataEntityTest")
                    .createdDate(timestamp)
                    .deletedDate(null)
                    .build();

    entityDetailsList.add(dataEntityDetails);

    final ExtEngagementDetails extEngagementDetails =
            ExtEngagementDetails.builder()
                    .assetId(111)
                    .extEngagementId(111)
                    .extEngagementValue("engage_test")
                    .createdDate(timestamp)
                    .deletedDate(null)
                    .build();

    extEngagementDetailsList.add(extEngagementDetails);

    final DataManagerConfig dmConfig =
            DataManagerConfig.builder()
                    .assetId(11)
                    .managedTypeDetails(managedTypeList)
                    .onboardStage(OnboardStage.PRODUCTION)
                    .dataStoreDetails(storeDetailsList)
                    .dataEntityDetails(entityDetailsList)
                    .extEngagementDetails(extEngagementDetailsList)
                    .createdDate(timestamp)
                    .deletedDate(null)
                    .build();

    Mockito.when(dataManagerRepository.findById(Mockito.anyLong()))
            .thenReturn(Optional.of(dmConfig));
    dataManagerService.getAssetById(111);
  }
}
