package com.intuit.dgorchworkerapp.statemachine.workeraccess;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.intuit.dgorchworkerapp.data.JobDao;
import com.intuit.dgorchworkerapp.data.WorkerAccessContextDao;
import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.JobKey;
import com.intuit.dgorchworkerapp.statemachine.JobType;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.CompressionCompleteAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.CompressionPendingAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.InProgressAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.LegalHoldsCheckInProgressAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.LegalHoldsPendingAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.PendingAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.QueuedAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.WorkerAccessAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccessitem.WorkerAccessItemState;
import com.intuit.dgorchworkerapp.statemachine.workeraccessitem.WorkerAccessItemStateMachine;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Test for worker access state machine.
 */
@ExtendWith(MockitoExtension.class)
public class WorkerAccessStateMachineTest {

  @Mock private JobDao jobDao;
  @Mock private WorkerAccessContextDao workerAccessContextDao;
  @Mock private WorkerAccessItemStateMachine workerAccessItemStateMachine;

  private final List<WorkerAccessAction> actions = Arrays.asList(
      mock(CompressionCompleteAction.class),
      mock(CompressionPendingAction.class),
      mock(InProgressAction.class),
      mock(LegalHoldsPendingAction.class),
      mock(LegalHoldsCheckInProgressAction.class),
      mock(PendingAction.class),
      mock(QueuedAction.class)
  );

  @Test
  public void testQueuedNextStateIsLegalHoldsPending() {
    final WorkerAccessStateMachine workerAccessStateMachine = new WorkerAccessStateMachine(
        jobDao, workerAccessContextDao, actions);

    final Job currentState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .state(WorkerAccessState.QUEUED.name())
        .build();

    final Job nextState = workerAccessStateMachine.nextState(currentState, null);

    assertEquals(WorkerAccessState.LEGAL_HOLDS_PENDING.name(), nextState.getState());
  }

  @Test
  public void testLegalHoldsPendingNextStateIsLegalHoldsCheckInProgress() {
    final WorkerAccessStateMachine workerAccessStateMachine = new WorkerAccessStateMachine(
        jobDao, workerAccessContextDao, actions);

    final Job currentState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .state(WorkerAccessState.LEGAL_HOLDS_PENDING.name())
        .build();

    final Job nextState = workerAccessStateMachine.nextState(currentState, null);

    assertEquals(WorkerAccessState.LEGAL_HOLDS_CHECK_IN_PROGRESS.name(), nextState.getState());
  }

  @Test
  public void testLegalHoldsCheckInProgressNextStateIsPending() {
    final WorkerAccessStateMachine workerAccessStateMachine = new WorkerAccessStateMachine(
        jobDao, workerAccessContextDao, actions);

    final Job currentState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .state(WorkerAccessState.LEGAL_HOLDS_CHECK_IN_PROGRESS.name())
        .build();

    final Job nextState = workerAccessStateMachine.nextState(currentState, null);

    assertEquals(WorkerAccessState.PENDING.name(), nextState.getState());
  }

  @Test
  public void testPendingNextStateIsInProgress() {
    final WorkerAccessStateMachine workerAccessStateMachine = new WorkerAccessStateMachine(
        jobDao, workerAccessContextDao, actions);

    final Job currentState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .state(WorkerAccessState.PENDING.name())
        .build();

    final Job nextState = workerAccessStateMachine.nextState(currentState, null);

    assertEquals(WorkerAccessState.IN_PROGRESS.name(), nextState.getState());
  }

  @Test
  public void testInProgressNextStateIsCompressionPending() {
    final WorkerAccessStateMachine workerAccessStateMachine = new WorkerAccessStateMachine(
        jobDao, workerAccessContextDao, actions);

    final Job currentState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .state(WorkerAccessState.IN_PROGRESS.name())
        .build();

    when(jobDao.getChildJobs(any())).thenReturn(Collections.emptyList());

    final Job nextState = workerAccessStateMachine.nextState(currentState, null);

    assertEquals(WorkerAccessState.COMPRESSION_PENDING.name(), nextState.getState());
  }

  @Test
  public void testInProgressNextStateIsStillInProgressIfPendingChildrenExist() {
    final WorkerAccessStateMachine workerAccessStateMachine = new WorkerAccessStateMachine(
        jobDao, workerAccessContextDao, actions);

    final Job currentState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .state(WorkerAccessState.IN_PROGRESS.name())
        .build();
    final Job pendingChildState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .jobType(JobType.WORKER_ACCESS_ITEM)
        .state(WorkerAccessItemState.PENDING.name())
        .build();

    when(jobDao.getChildJobs(any())).thenReturn(Collections.singletonList(pendingChildState));

    final Job nextState = workerAccessStateMachine.nextState(currentState, null);

    assertEquals(WorkerAccessState.IN_PROGRESS.name(), nextState.getState());
  }

  @Test
  public void testCompressionPendingNextStateIsCompressionComplete() {
    final WorkerAccessStateMachine workerAccessStateMachine = new WorkerAccessStateMachine(
        jobDao, workerAccessContextDao, actions);

    final Job currentState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .state(WorkerAccessState.COMPRESSION_PENDING.name())
        .build();

    final Job nextState = workerAccessStateMachine.nextState(currentState, null);

    assertEquals(WorkerAccessState.COMPRESSION_COMPLETE.name(), nextState.getState());
  }

  @Test
  public void testCompressionCompleteNextStateIsProcessed() {
    final WorkerAccessStateMachine workerAccessStateMachine = new WorkerAccessStateMachine(
        jobDao, workerAccessContextDao, actions);

    final Job currentState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .state(WorkerAccessState.COMPRESSION_COMPLETE.name())
        .build();

    final Job nextState = workerAccessStateMachine.nextState(currentState, null);

    assertEquals(WorkerAccessState.PROCESSED.name(), nextState.getState());
  }

  @Test
  public void testInvalidStateThrows() {
    final WorkerAccessStateMachine workerAccessStateMachine = new WorkerAccessStateMachine(
        jobDao, workerAccessContextDao, actions);

    final Job currentState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .state(WorkerAccessState.CANCELLED.name())
        .build();

    assertThrows(RuntimeException.class,
        () -> workerAccessStateMachine.nextState(currentState, null));
  }

  @Test
  public void testOnExceptionReturnsSameState() {
    final WorkerAccessStateMachine workerAccessStateMachine = new WorkerAccessStateMachine(
        jobDao, workerAccessContextDao, actions);

    final Job currentState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .state(WorkerAccessState.IN_PROGRESS.name())
        .build();

    assertEquals(currentState, workerAccessStateMachine.onException(currentState, null, null));
  }

  @Test
  public void testCancelReturnsCancelledState() {
    final WorkerAccessStateMachine workerAccessStateMachine = new WorkerAccessStateMachine(
        jobDao, workerAccessContextDao, actions);

    final Job currentState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .state(WorkerAccessState.QUEUED.name())
        .build();

    final Job canceledState = workerAccessStateMachine.cancel(currentState, null, "");

    assertEquals(WorkerAccessState.CANCELLED.name(), canceledState.getState());
  }
}
