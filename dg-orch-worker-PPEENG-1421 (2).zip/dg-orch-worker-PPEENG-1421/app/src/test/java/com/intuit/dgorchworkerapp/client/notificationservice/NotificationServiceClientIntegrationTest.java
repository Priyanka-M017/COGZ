package com.intuit.dgorchworkerapp.client.notificationservice;

import com.intuit.dgorchworkerapp.client.notificationservice.model.AccessNotificationEvent;
import com.intuit.dgorchworkerapp.client.notificationservice.model.NotificationEventType;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * Temp integ test to get ticket.
 */
@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT
)
@ActiveProfiles(profiles = {"local"})
public class NotificationServiceClientIntegrationTest {

  @Autowired
  private NotificationServiceClient notificationServiceClient;

  @Test
  public void test() {
    notificationServiceClient.sendNotification(
        NotificationEventType.WORKER_ACCESS_REQUEST_RECEIVED,
        AccessNotificationEvent.builder()
            .firstName("Test")
            .persona("persona")
            .email("iamteste2e15@mailinator.com")
            .build(),
        "-1",
        UUID.randomUUID().toString());
  }
}
