package com.intuit.dgorchworkerapp.statemachine.workeraccess.actions;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.intuit.dgorchworkerapp.data.JobDao;
import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.JobKey;
import com.intuit.dgorchworkerapp.statemachine.JobType;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.WorkerAccessState;
import com.intuit.dgorchworkerapp.statemachine.workeraccessitem.WorkerAccessItemState;
import com.intuit.dgworker.entity.DgWorkerEvent;
import java.util.Collections;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;

/**
 * Test for in progress worker access action.
 */
@ExtendWith(MockitoExtension.class)
public class InProgressActionTest {

  @Mock private KafkaTemplate<String, DgWorkerEvent> kafkaTemplate;
  @Mock private JobDao jobDao;

  @InjectMocks private InProgressAction inProgressAction;

  @Test
  public void testSendReminderIfPendingChildrenExists() {
    final Job currentState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.IN_PROGRESS.name())
        .build();
    final Job pendingChildState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .jobType(JobType.WORKER_ACCESS_ITEM)
        .state(WorkerAccessItemState.PENDING.name())
        .build();

    when(jobDao.getChildJobs(any())).thenReturn(Collections.singletonList(pendingChildState));

    inProgressAction.onExecute(currentState, null);

    verify(kafkaTemplate, times(1)).sendDefault(any());
  }

  @Test
  public void testDoNotSendReminderIfPendingChildrenDoNotExist() {
    final Job currentState = Job.builder()
        .jobKey(new JobKey(UUID.randomUUID().toString(), 0))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.IN_PROGRESS.name())
        .build();

    when(jobDao.getChildJobs(any())).thenReturn(Collections.emptyList());

    inProgressAction.onExecute(currentState, null);

    verifyNoInteractions(kafkaTemplate);
  }
}
