package com.intuit.dgorchworkerapp.statemachine.workeraccess.actions;

import com.intuit.dgorchworkerapp.data.models.WorkerAccessContext;
import org.junit.jupiter.api.Test;

/**
 * Test for compression pending.
 */
public class CompressionCompleteTest {

  @Test
  public void testAction() {
    final CompressionCompleteAction compressionCompleteAction = new CompressionCompleteAction();

    compressionCompleteAction.onExecute(null, new WorkerAccessContext());
  }
}
