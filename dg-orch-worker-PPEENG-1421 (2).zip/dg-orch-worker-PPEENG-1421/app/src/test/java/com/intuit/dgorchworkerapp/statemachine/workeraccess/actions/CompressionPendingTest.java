package com.intuit.dgorchworkerapp.statemachine.workeraccess.actions;

import com.intuit.dgorchworkerapp.data.models.WorkerAccessContext;
import org.junit.jupiter.api.Test;

/**
 * Test for compression pending.
 */
public class CompressionPendingTest {

  @Test
  public void testAction() {
    final CompressionPendingAction compressionPendingAction = new CompressionPendingAction();

    compressionPendingAction.onExecute(null, new WorkerAccessContext());
  }
}
