package com.intuit.dgorchworkerapp.statemachine;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.intuit.dgorchworkerapp.data.JobContextDao;
import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.JobContext;
import com.intuit.dgorchworkerapp.data.models.JobKey;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.Getter;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class StateMachineTest {

  @Mock
  private JobContextDao<TestJobContext, String> mockJobContextDao;

  @SuppressWarnings("unchecked")
  private static final StateMachine<TestJobContext, TestJobState> mockStateMachine =
      mock(StateMachine.class);

  @SuppressWarnings("unchecked")
  private static final Action<TestJobContext> mockAction = mock(Action.class);

  @Test
  public void testConstructorNoInitialStateDeclared() {
    assertThrows(RuntimeException.class, () -> new TestStateMachine<>(
        mockJobContextDao,
        Collections.singletonList(new TestAction()),
        TestJobStateWithoutInitialState.class,
        JobType.WORKER_ACCESS
    ));
  }

  @Test
  public void testConstructorMultipleInitialStatesDeclared() {
    assertThrows(RuntimeException.class, () -> new TestStateMachine<>(
        mockJobContextDao,
        Collections.singletonList(new TestAction()),
        TestJobStateWithMultipleInitialStates.class,
        JobType.WORKER_ACCESS
    ));
  }

  @Test
  public void testConstructorActionNotAssignedToState() {
    assertThrows(RuntimeException.class, () -> new TestStateMachine<>(
        mockJobContextDao,
        Collections.singletonList(new TestAction()),
        TestJobStateActionNotAssignedToState.class,
        JobType.WORKER_ACCESS
    ));
  }

  @Test
  public void testConstructorActiveStateNotAssignedAction() {
    assertThrows(RuntimeException.class, () -> new TestStateMachine<>(
        mockJobContextDao,
        Collections.singletonList(new TestAction()),
        TestJobActiveStateNotAssignedAction.class,
        JobType.WORKER_ACCESS
    ));
  }

  @Test
  public void submitNewJob() {
    final StateMachine<TestJobContext, ? extends State> testStateMachine = new TestStateMachine<>(
        mockJobContextDao,
        Collections.singletonList(new TestAction()),
        TestJobState.class,
        JobType.WORKER_ACCESS
    );

    testStateMachine.submit(UUID.randomUUID().toString(), new TestJobContext(), null);

    verify(mockJobContextDao).save(any());
  }

  @Test
  public void testExecute() throws Exception {
    final StateMachine<TestJobContext, ? extends State> testStateMachine = new TestStateMachine<>(
        mockJobContextDao,
        Collections.singletonList(new TestAction()),
        TestJobState.class,
        JobType.WORKER_ACCESS
    );
    final String testJobId = "123456";
    final Job testJob = Job.builder()
        .jobKey(new JobKey(testJobId, 0))
        .state(TestJobState.TEST_STATE_1.name())
        .build();
    final Job newJobState = Job.builder()
        .jobKey(new JobKey(testJobId, 1))
        .state(TestJobState.TEST_STATE_2.name())
        .build();
    final TestJobContext testContext = new TestJobContext();

    when(mockJobContextDao.findById(eq(testJobId))).thenReturn(Optional.of(testContext));
    when(mockAction.onExecute(eq(testJob), eq(testContext))).thenReturn(testContext);
    when(mockStateMachine.nextState(eq(testJob), eq(testContext))).thenReturn(newJobState);

    final Job newJob = testStateMachine.execute(testJob);

    assertSame(newJobState, newJob);
    verify(mockAction).onExecute(eq(testJob), eq(testContext));
    verify(mockStateMachine).nextState(eq(testJob), eq(testContext));
  }

  @Test
  public void testExecuteActionException() throws Exception {
    final StateMachine<TestJobContext, ? extends State> testStateMachine = new TestStateMachine<>(
        mockJobContextDao,
        Collections.singletonList(new TestAction()),
        TestJobState.class,
        JobType.WORKER_ACCESS
    );
    final String testJobId = "123456";
    final Job testJob = Job.builder()
        .jobKey(new JobKey(testJobId, 0))
        .state(TestJobState.TEST_STATE_1.name())
        .build();
    final Job newJobState = Job.builder()
        .jobKey(new JobKey(testJobId, 1))
        .state(TestJobState.TEST_STATE_2.name())
        .build();
    final TestJobContext testContext = new TestJobContext();

    when(mockJobContextDao.findById(eq(testJobId))).thenReturn(Optional.of(testContext));
    when(mockAction.onExecute(eq(testJob), eq(testContext))).thenThrow(RuntimeException.class);
    when(mockStateMachine.onException(eq(testJob), eq(testContext), any())).thenReturn(newJobState);

    final Job newJob = testStateMachine.execute(testJob);

    assertSame(newJobState, newJob);
    verify(mockAction).onExecute(eq(testJob), eq(testContext));
    verify(mockStateMachine).onException(eq(testJob), eq(testContext), any());
  }

  @Test
  public void testCallback() throws Exception {
    final StateMachine<TestJobContext, ? extends State> testStateMachine = new TestStateMachine<>(
        mockJobContextDao,
        Collections.singletonList(new TestAction()),
        TestJobState.class,
        JobType.WORKER_ACCESS
    );
    final String testJobId = "123456";
    final Job testJob = Job.builder()
        .jobKey(new JobKey(testJobId, 0))
        .state(TestJobState.TEST_STATE_1.name())
        .build();
    final Job newJobState = Job.builder()
        .jobKey(new JobKey(testJobId, 1))
        .state(TestJobState.TEST_STATE_2.name())
        .build();
    final TestJobContext testContext = new TestJobContext();
    final String callbackBody = "body";

    when(mockJobContextDao.findById(eq(testJobId)))
        .thenReturn(Optional.of(testContext));
    when(mockAction.onCallback(eq(testJob), eq(testContext), eq(callbackBody)))
        .thenReturn(testContext);
    when(mockStateMachine.nextState(eq(testJob), eq(testContext)))
        .thenReturn(newJobState);

    final Job newJob = testStateMachine.callback(testJob, callbackBody);

    assertSame(newJobState, newJob);
    verify(mockAction).onCallback(eq(testJob), eq(testContext), eq(callbackBody));
    verify(mockStateMachine).nextState(eq(testJob), eq(testContext));
  }

  @Test
  public void testCallbackActionException() throws Exception {
    final StateMachine<TestJobContext, ? extends State> testStateMachine = new TestStateMachine<>(
        mockJobContextDao,
        Collections.singletonList(new TestAction()),
        TestJobState.class,
        JobType.WORKER_ACCESS
    );
    final String testJobId = "123456";
    final Job testJob = Job.builder()
        .jobKey(new JobKey(testJobId, 0))
        .state(TestJobState.TEST_STATE_1.name())
        .build();
    final Job newJobState = Job.builder()
        .jobKey(new JobKey(testJobId, 1))
        .state(TestJobState.TEST_STATE_2.name())
        .build();
    final TestJobContext testContext = new TestJobContext();
    final String callbackBody = "body";

    when(mockJobContextDao.findById(eq(testJobId)))
        .thenReturn(Optional.of(testContext));
    when(mockAction.onCallback(eq(testJob), eq(testContext), eq(callbackBody)))
        .thenThrow(RuntimeException.class);
    when(mockStateMachine.onException(eq(testJob), eq(testContext), any()))
        .thenReturn(newJobState);

    final Job newJob = testStateMachine.callback(testJob, callbackBody);

    assertSame(newJobState, newJob);
    verify(mockAction).onCallback(eq(testJob), eq(testContext), eq(callbackBody));
    verify(mockStateMachine).onException(eq(testJob), eq(testContext), any());
  }

  @Test
  public void testCancel() {
    final StateMachine<TestJobContext, ? extends State> testStateMachine = new TestStateMachine<>(
        mockJobContextDao,
        Collections.singletonList(new TestAction()),
        TestJobState.class,
        JobType.WORKER_ACCESS
    );
    final String testJobId = "123456";
    final Job testJob = Job.builder()
        .jobKey(new JobKey(testJobId, 0))
        .state(TestJobState.TEST_STATE_1.name())
        .build();
    final String testDescription = "description";

    when(mockStateMachine.cancel(eq(testJob), eq(testDescription))).thenReturn(testJob);

    final Job result = testStateMachine.cancel(testJob, testDescription);

    verify(mockStateMachine).cancel(eq(testJob), eq(testDescription));
    assertEquals(testJob.getState(), result.getState());
  }

  @Test
  public void testAttemptCancelOnNotCancelableState() {
    final StateMachine<TestJobContext, ? extends State> testStateMachine = new TestStateMachine<>(
        mockJobContextDao,
        Collections.singletonList(new TestAction()),
        TestJobState.class,
        JobType.WORKER_ACCESS
    );
    final String testJobId = "123456";
    final Job testJob = Job.builder()
        .jobKey(new JobKey(testJobId, 0))
        .state(TestJobState.TEST_STATE_2.name())
        .build();
    final String testDescription = "description";

    assertThrows(RuntimeException.class, () -> testStateMachine.cancel(testJob, testDescription));

    verify(mockStateMachine, times(0)).cancel(any(Job.class), any());
  }

  @Test
  public void testGetDetail() {
    final StateMachine<TestJobContext, ? extends State> testStateMachine = new TestStateMachine<>(
        mockJobContextDao,
        Collections.singletonList(new TestAction()),
        TestJobState.class,
        JobType.WORKER_ACCESS
    );
    final String testJobId = "123456";
    final Job testJob = Job.builder().jobKey(new JobKey(testJobId, 0)).build();
    final TestJobContext testJobContext = new TestJobContext();

    when(mockJobContextDao.findById(eq(testJobId))).thenReturn(Optional.of(testJobContext));

    assertSame(testJobContext, testStateMachine.getContext(testJob));
  }

  @Test
  public void testGetDetailNoContext() {
    final StateMachine<TestJobContext, ? extends State> testStateMachine = new TestStateMachine<>(
        mockJobContextDao,
        Collections.singletonList(new TestAction()),
        TestJobState.class,
        JobType.WORKER_ACCESS
    );
    final String testJobId = "123456";
    final Job testJob = Job.builder().jobKey(new JobKey(testJobId, 0)).build();

    when(mockJobContextDao.findById(eq(testJobId))).thenReturn(Optional.empty());

    assertNull(testStateMachine.getContext(testJob));
  }

  private static class TestStateMachine<T extends Enum<? extends State>>
      extends StateMachine<TestJobContext, T> {

    public TestStateMachine(
        final JobContextDao<TestJobContext, String> jobContextDao,
        final List<? extends Action<TestJobContext>> actions,
        final Class<T> statesClass,
        final JobType jobType
    ) {
      super(jobContextDao, actions, statesClass, jobType);
    }

    @Override
    protected Job nextState(final Job job, final TestJobContext context) {
      return mockStateMachine.nextState(job, context);
    }

    @Override
    protected Job onException(final Job job, final TestJobContext context, final Exception e) {
      return mockStateMachine.onException(job, context, e);
    }

    @Override
    protected Job cancel(final Job job, final TestJobContext context, final String description) {
      return mockStateMachine.cancel(job, description);
    }
  }

  private static class TestAction implements Action<TestJobContext> {

    @Override
    public TestJobContext onExecute(final Job job, final TestJobContext context) throws Exception {
      return mockAction.onExecute(job, context);
    }

    @Override
    public TestJobContext onCallback(
        final Job job,
        final TestJobContext context,
        final String body
    ) throws Exception {
      return mockAction.onCallback(job, context, body);
    }
  }

  private static class TestJobContext implements JobContext {

    @Override
    public String getId() {
      return "123456";
    }

    @Override
    public TestJobContext withId(final String id) {
      return new TestJobContext();
    }
  }

  @Getter
  private enum TestJobState implements State {
    TEST_STATE_1(TestAction.class, StateAttributes.INITIAL, StateAttributes.CANCELABLE),
    TEST_STATE_2(null);

    private final Class<? extends Action<TestJobContext>> actionClass;
    private final EnumSet<StateAttributes> attributes;

    TestJobState(
        final Class<? extends Action<TestJobContext>> actionClass,
        final StateAttributes... attributes
    ) {
      this.actionClass = actionClass;
      this.attributes = attributes.length > 0
          ? EnumSet.copyOf(Arrays.asList(attributes))
          : EnumSet.noneOf(StateAttributes.class);
    }
  }

  @Getter
  private enum TestJobStateWithoutInitialState implements State {
    TEST_STATE_1(TestAction.class),
    TEST_STATE_2(null);

    private final Class<? extends Action<TestJobContext>> actionClass;
    private final EnumSet<StateAttributes> attributes;

    TestJobStateWithoutInitialState(
        final Class<? extends Action<TestJobContext>> actionClass,
        final StateAttributes... attributes
    ) {
      this.actionClass = actionClass;
      this.attributes = attributes.length > 0
          ? EnumSet.copyOf(Arrays.asList(attributes))
          : EnumSet.noneOf(StateAttributes.class);
    }
  }

  @Getter
  private enum TestJobStateWithMultipleInitialStates implements State {
    TEST_STATE_1(TestAction.class, StateAttributes.INITIAL),
    TEST_STATE_2(null, StateAttributes.INITIAL);

    private final Class<? extends Action<TestJobContext>> actionClass;
    private final EnumSet<StateAttributes> attributes;

    TestJobStateWithMultipleInitialStates(
        final Class<? extends Action<TestJobContext>> actionClass,
        final StateAttributes... attributes
    ) {
      this.actionClass = actionClass;
      this.attributes = attributes.length > 0
          ? EnumSet.copyOf(Arrays.asList(attributes))
          : EnumSet.noneOf(StateAttributes.class);
    }
  }

  @Getter
  private enum TestJobStateActionNotAssignedToState implements State {
    TEST_STATE_1(null, StateAttributes.INITIAL),
    TEST_STATE_2(null);

    private final Class<? extends Action<TestJobContext>> actionClass;
    private final EnumSet<StateAttributes> attributes;

    TestJobStateActionNotAssignedToState(
        final Class<? extends Action<TestJobContext>> actionClass,
        final StateAttributes... attributes
    ) {
      this.actionClass = actionClass;
      this.attributes = attributes.length > 0
          ? EnumSet.copyOf(Arrays.asList(attributes))
          : EnumSet.noneOf(StateAttributes.class);
    }
  }

  @Getter
  private enum TestJobActiveStateNotAssignedAction implements State {
    TEST_STATE_1(null, StateAttributes.INITIAL, StateAttributes.ACTIVE),
    TEST_STATE_2(TestAction.class);

    private final Class<? extends Action<TestJobContext>> actionClass;
    private final EnumSet<StateAttributes> attributes;

    TestJobActiveStateNotAssignedAction(
        final Class<? extends Action<TestJobContext>> actionClass,
        final StateAttributes... attributes
    ) {
      this.actionClass = actionClass;
      this.attributes = attributes.length > 0
          ? EnumSet.copyOf(Arrays.asList(attributes))
          : EnumSet.noneOf(StateAttributes.class);
    }
  }
}
