package com.intuit.dgorchworkerapp.client.wids;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.web.reactive.function.client.WebClient;

class WidsServiceClientTest {

  @Disabled
  @Test
  public void test() {
    final ClientRegistrationRepository clientRegistrationRepository =
        new InMemoryClientRegistrationRepository(
            ClientRegistration.withRegistrationId("authProvider")
                .authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
                .clientId("testClient")
                .clientSecret("testSecret")
                .tokenUri("http://localhost:8888/oauth2/v1/tokens/bearer")
                .build());

    final WidsServiceClient widsServiceClient = new WidsServiceClient(
        new WidsServiceProperties("http://localhost:8888"),
        clientRegistrationRepository,
        null,
        WebClient.create()
    );

    widsServiceClient.query("network", "test");
  }

}
