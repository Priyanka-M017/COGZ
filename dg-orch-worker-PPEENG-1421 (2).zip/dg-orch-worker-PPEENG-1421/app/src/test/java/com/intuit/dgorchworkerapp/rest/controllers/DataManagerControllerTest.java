package com.intuit.dgorchworkerapp.rest.controllers;

import static org.mockito.Mockito.when;

import com.intuit.dgorchworkerapp.data.models.DataEntityDetails;
import com.intuit.dgorchworkerapp.data.models.DataManagerConfig;
import com.intuit.dgorchworkerapp.data.models.DataStoreDetails;
import com.intuit.dgorchworkerapp.data.models.ExtEngagementDetails;
import com.intuit.dgorchworkerapp.data.models.ManagedType;
import com.intuit.dgorchworkerapp.data.models.OnboardStage;
import com.intuit.dgorchworkerapp.repository.DataManagerRepository;
import com.intuit.dgorchworkerapp.rest.controllers.model.DataManagerConfigDto;
import com.intuit.dgorchworkerapp.service.DataManagerService;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Unit test case for the Controller class.
 */
@ExtendWith(MockitoExtension.class)
public class DataManagerControllerTest {

  private final long assetId = 1;
  private final List<ManagedType> managedTypeList = new ArrayList<>();
  private final List<DataStoreDetails> storeDetailsList = new ArrayList<>();
  private final List<DataEntityDetails> entityDetailsList = new ArrayList<>();
  private final List<ExtEngagementDetails> extEngagementDetailsList = new ArrayList<>();
  private final Timestamp timestamp = new Timestamp(System.currentTimeMillis());

  @Autowired private DataManagerRepository dataManagerRepository;
  @Mock private DataManagerService dataManagerService;

  /**
   * Unit test case for the testGetByAssetId method.
   */
  @Test
  public void testGetByAssetId() {

    final DataManagerController dataManagerController =
            new DataManagerController(dataManagerService, dataManagerRepository);

    final ManagedType managedType = ManagedType.builder()
            .assetId(11)
            .managedTypeId(11)
            .managedTypeValue("INTERNAL")
            .createdDate(timestamp)
            .deletedDate(null)
            .build();

    managedTypeList.add(managedType);

    final DataStoreDetails dataStoreDetails =
            DataStoreDetails.builder()
                    .assetId(11)
                    .dataStoreId(11)
                    .dataStoreValue("dataStoreTest")
                    .createdDate(timestamp)
                    .deletedDate(null)
                    .build();

    storeDetailsList.add(dataStoreDetails);

    final DataEntityDetails dataEntityDetails =
            DataEntityDetails.builder()
                    .assetId(11)
                    .dataEntityId(11)
                    .dataEntityValue("dataEntityTest")
                    .createdDate(timestamp)
                    .deletedDate(null)
                    .build();

    entityDetailsList.add(dataEntityDetails);

    final ExtEngagementDetails extEngagementDetails =
            ExtEngagementDetails.builder()
                    .assetId(111)
                    .extEngagementId(111)
                    .extEngagementValue("engage_test")
                    .createdDate(timestamp)
                    .deletedDate(null)
                    .build();

    extEngagementDetailsList.add(extEngagementDetails);

    final DataManagerConfig dmConfig =
            DataManagerConfig.builder()
                    .assetId(11)
                    .managedTypeDetails(managedTypeList)
                    .onboardStage(OnboardStage.PRODUCTION)
                    .dataStoreDetails(storeDetailsList)
                    .dataEntityDetails(entityDetailsList)
                    .extEngagementDetails(extEngagementDetailsList)
                    .createdDate(timestamp)
                    .deletedDate(null)
                    .build();

    final DataManagerConfigDto dmConfigDto = DataManagerConfigDto.builder()
            .assetId(dmConfig.getAssetId())
            .managedTypeList(dmConfig.getManagedTypeDetails())
            .dataStoreDetails(dmConfig.getDataStoreDetails())
            .dataEntityDetails(dmConfig.getDataEntityDetails())
            .extEngagementDetails(dmConfig.getExtEngagementDetails())
            .createdDate(dmConfig.getCreatedDate())
            .deletedDate(dmConfig.getDeletedDate())
            .build();

    when(dataManagerService.getAssetById(Mockito.anyInt())).thenReturn(dmConfigDto);
    dataManagerController.getAssetById(11);
  }

  /**
   * Unit test case for the testSaveDataManagerConfigDetails method.
   */
  @Test
  public void testSaveDataManagerConfigDetails() {

    final DataManagerController dataManagerController =
            new DataManagerController(dataManagerService, dataManagerRepository);

    final ManagedType managedType = ManagedType.builder()
            .assetId(11)
            .managedTypeId(11)
            .managedTypeValue("INTERNAL")
            .createdDate(timestamp)
            .deletedDate(null)
            .build();

    managedTypeList.add(managedType);

    final DataStoreDetails dataStoreDetails =
            DataStoreDetails.builder()
                    .assetId(11)
                    .dataStoreId(11)
                    .dataStoreValue("dataStoreTest")
                    .createdDate(timestamp)
                    .deletedDate(null)
                    .build();

    storeDetailsList.add(dataStoreDetails);

    final DataEntityDetails dataEntityDetails =
            DataEntityDetails.builder()
                    .assetId(11)
                    .dataEntityId(11)
                    .dataEntityValue("dataEntityTest")
                    .createdDate(timestamp)
                    .deletedDate(null)
                    .build();

    entityDetailsList.add(dataEntityDetails);

    final ExtEngagementDetails extEngagementDetails =
            ExtEngagementDetails.builder()
                    .assetId(111)
                    .extEngagementId(111)
                    .extEngagementValue("engage_test")
                    .createdDate(timestamp)
                    .deletedDate(null)
                    .build();

    extEngagementDetailsList.add(extEngagementDetails);

    final DataManagerConfig dmConfig =
            DataManagerConfig.builder()
                    .assetId(11)
                    .managedTypeDetails(managedTypeList)
                    .onboardStage(OnboardStage.PRODUCTION)
                    .dataStoreDetails(storeDetailsList)
                    .dataEntityDetails(entityDetailsList)
                    .extEngagementDetails(extEngagementDetailsList)
                    .createdDate(timestamp)
                    .deletedDate(null)
                    .build();

    final DataManagerConfigDto dmConfigDto = DataManagerConfigDto.builder()
            .assetId(dmConfig.getAssetId())
            .onboardStage(OnboardStage.PRODUCTION)
            .managedTypeList(managedTypeList)
            .dataStoreDetails(storeDetailsList)
            .dataEntityDetails(entityDetailsList)
            .extEngagementDetails(extEngagementDetailsList)
            .createdDate(dmConfig.getCreatedDate())
            .deletedDate(dmConfig.getDeletedDate())
            .build();

    when(dataManagerService.saveOrUpdate(Mockito.any())).thenReturn(dmConfigDto);
    dataManagerController.saveDataManagerConfigDetails(dmConfigDto);

  }
}
