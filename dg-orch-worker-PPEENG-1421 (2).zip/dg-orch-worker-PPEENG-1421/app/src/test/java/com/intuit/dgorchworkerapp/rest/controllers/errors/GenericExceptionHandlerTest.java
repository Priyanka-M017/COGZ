package com.intuit.dgorchworkerapp.rest.controllers.errors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

/**
 * Test for GenericExceptionHandlerTest.
 */
public class GenericExceptionHandlerTest {
  @Test
  public void testHandleOtherErrors() {
    final GenericExceptionHandler genericExceptionHandler = new GenericExceptionHandler();
    final Throwable e = mock(Throwable.class);
    final SimpleErrorResponse response = genericExceptionHandler.handleOtherErrors(e);
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
  }

}
