package com.intuit.dgorchworkerapp.rest.controllers.errors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

/**
 * Test for SimpleErrorResponseTest.
 */
public class SimpleErrorResponseTest {
  @Test
  public void testConstructor() {
    final String msg = "friendly msg";
    final SimpleErrorResponse simpleErrorResponse = new SimpleErrorResponse(msg, true);
    assertTrue(simpleErrorResponse.getBody().toString().contains(msg));
  }

  @Test
  public void testConstructorWithThrowable() {
    final String msg = "friendly msg";
    final SimpleErrorResponse simpleErrorResponse =
        new SimpleErrorResponse(msg, mock(Throwable.class), true);
    assertTrue(simpleErrorResponse.getBody().toString().contains(msg));
  }

  @Test
  public void testConstructorWithStatusCode() {
    final String msg = "friendly msg";
    final SimpleErrorResponse simpleErrorResponse =
        new SimpleErrorResponse(HttpStatus.I_AM_A_TEAPOT, msg, true);
    assertTrue(simpleErrorResponse.getBody().toString().contains(msg));
    assertEquals(HttpStatus.I_AM_A_TEAPOT, simpleErrorResponse.getStatusCode());
  }

  @Test
  public void testConstructorWithStatusCodeAndThrowable() {
    final String msg = "friendly msg";
    final SimpleErrorResponse simpleErrorResponse =
        new SimpleErrorResponse(HttpStatus.I_AM_A_TEAPOT, msg, mock(Throwable.class), true);
    assertTrue(simpleErrorResponse.getBody().toString().contains(msg));
    assertEquals(HttpStatus.I_AM_A_TEAPOT, simpleErrorResponse.getStatusCode());
  }
}
