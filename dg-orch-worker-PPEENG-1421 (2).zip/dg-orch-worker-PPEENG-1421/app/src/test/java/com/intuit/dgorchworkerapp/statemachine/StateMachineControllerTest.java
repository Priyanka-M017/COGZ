package com.intuit.dgorchworkerapp.statemachine;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.intuit.dgorchworkerapp.data.JobDao;
import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.JobKey;
import com.intuit.dgorchworkerapp.data.models.WorkerAccessContext;
import com.intuit.dgorchworkerapp.rest.controllers.model.JobDetailResponse;
import com.intuit.dgorchworkerapp.rest.controllers.model.JobResponse;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.WorkerAccessState;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.WorkerAccessStateMachine;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.AdditionalAnswers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Test for the state machine controller.
 */
@ExtendWith(MockitoExtension.class)
public class StateMachineControllerTest {

  @Mock
  private JobDao mockJobDao;

  @Mock
  private WorkerAccessStateMachine mockStateMachine;

  @Test
  public void testSubmitJob() {
    final StateMachineController stateMachineController = new StateMachineController(
        mockJobDao,
        Collections.singletonList(mockStateMachine));
    final Job testJob = Job.builder().jobKey(new JobKey(UUID.randomUUID().toString(), 0)).build();

    when(mockStateMachine.submit(any(), any(), any())).thenReturn(testJob);
    when(mockJobDao.save(any())).then(AdditionalAnswers.returnsFirstArg());

    final Job result = stateMachineController.submit(JobType.WORKER_ACCESS, null, null);

    assertSame(testJob, result);
    verify(mockJobDao).save(eq(testJob));
  }

  @Test
  public void testExecuteJob() {
    final StateMachineController stateMachineController = new StateMachineController(
        mockJobDao,
        Collections.singletonList(mockStateMachine));
    final String jobId = UUID.randomUUID().toString();
    final Job currentState = Job.builder()
        .jobKey(new JobKey(jobId, 0))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.QUEUED.name())
        .build();
    final Job nextState = Job.builder()
        .jobKey(new JobKey(jobId, 1))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.PENDING.name())
        .build();

    when(mockJobDao.getCurrentState(any())).thenReturn(currentState);
    when(mockStateMachine.execute(any())).thenReturn(nextState);
    when(mockJobDao.save(any())).then(AdditionalAnswers.returnsFirstArg());

    final Job result = stateMachineController.execute(jobId);

    assertSame(nextState, result);
    verify(mockJobDao).save(eq(nextState));
  }

  @Test
  public void testExecuteJobSameState() {
    final StateMachineController stateMachineController = new StateMachineController(
        mockJobDao,
        Collections.singletonList(mockStateMachine));
    final String jobId = UUID.randomUUID().toString();
    final Job currentState = Job.builder()
        .jobKey(new JobKey(jobId, 0))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.QUEUED.name())
        .build();
    final Job nextState = Job.builder()
        .jobKey(new JobKey(jobId, 0))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.QUEUED.name())
        .build();

    when(mockJobDao.getCurrentState(any())).thenReturn(currentState);
    when(mockStateMachine.execute(any())).thenReturn(nextState);

    final Job result = stateMachineController.execute(jobId);

    assertSame(currentState, result);
    verify(mockJobDao, times(0)).save(eq(nextState));
  }

  @Test
  public void testCallbackJob() {
    final StateMachineController stateMachineController = new StateMachineController(
        mockJobDao,
        Collections.singletonList(mockStateMachine));
    final String jobId = UUID.randomUUID().toString();
    final Job currentState = Job.builder()
        .jobKey(new JobKey(jobId, 0))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.QUEUED.name())
        .build();
    final Job nextState = Job.builder()
        .jobKey(new JobKey(jobId, 1))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.PENDING.name())
        .build();

    when(mockJobDao.getCurrentState(any())).thenReturn(currentState);
    when(mockStateMachine.callback(any(), any())).thenReturn(nextState);
    when(mockJobDao.save(any())).then(AdditionalAnswers.returnsFirstArg());

    final Job result = stateMachineController.callback(jobId, "body");

    assertSame(nextState, result);
    verify(mockJobDao).save(eq(nextState));
  }

  @Test
  public void testCallbackJobSameState() {
    final StateMachineController stateMachineController = new StateMachineController(
        mockJobDao,
        Collections.singletonList(mockStateMachine));
    final String jobId = UUID.randomUUID().toString();
    final Job currentState = Job.builder()
        .jobKey(new JobKey(jobId, 0))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.QUEUED.name())
        .build();
    final Job nextState = Job.builder()
        .jobKey(new JobKey(jobId, 0))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.QUEUED.name())
        .build();

    when(mockJobDao.getCurrentState(any())).thenReturn(currentState);
    when(mockStateMachine.callback(any(), any())).thenReturn(nextState);

    final Job result = stateMachineController.callback(jobId, "body");

    assertSame(currentState, result);
    verify(mockJobDao, times(0)).save(eq(nextState));
  }

  @Test
  public void testCancelJob() {
    final StateMachineController stateMachineController = new StateMachineController(
        mockJobDao,
        Collections.singletonList(mockStateMachine));
    final String jobId = UUID.randomUUID().toString();
    final Job currentState = Job.builder()
        .jobKey(new JobKey(jobId, 0))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.QUEUED.name())
        .build();
    final Job nextState = Job.builder()
        .jobKey(new JobKey(jobId, 1))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.PENDING.name())
        .build();

    when(mockJobDao.getCurrentState(any())).thenReturn(currentState);
    when(mockStateMachine.cancel(any(), any())).thenReturn(nextState);
    when(mockJobDao.save(any())).then(AdditionalAnswers.returnsFirstArg());

    final Job result = stateMachineController.cancel(jobId, "desc");

    assertSame(nextState, result);
    verify(mockJobDao).save(eq(nextState));
  }

  @Test
  public void testCancelJobSameState() {
    final StateMachineController stateMachineController = new StateMachineController(
        mockJobDao,
        Collections.singletonList(mockStateMachine));
    final String jobId = UUID.randomUUID().toString();
    final Job currentState = Job.builder()
        .jobKey(new JobKey(jobId, 0))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.QUEUED.name())
        .build();
    final Job nextState = Job.builder()
        .jobKey(new JobKey(jobId, 0))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.QUEUED.name())
        .build();

    when(mockJobDao.getCurrentState(any())).thenReturn(currentState);
    when(mockStateMachine.cancel(any(), any())).thenReturn(nextState);

    final Job result = stateMachineController.cancel(jobId, "desc");

    assertSame(currentState, result);
    verify(mockJobDao, times(0)).save(eq(nextState));
  }

  @Test
  public void testGetJobDetail() {
    final StateMachineController stateMachineController = new StateMachineController(
        mockJobDao,
        Collections.singletonList(mockStateMachine));
    final String jobId = UUID.randomUUID().toString();
    final Job state0 = Job.builder()
        .jobKey(new JobKey(jobId, 0))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.QUEUED.name())
        .build();
    final Job state1 = Job.builder()
        .jobKey(new JobKey(jobId, 1))
        .jobType(JobType.WORKER_ACCESS)
        .state(WorkerAccessState.PENDING.name())
        .build();
    final List<Job> allStates = Arrays.asList(state0, state1);
    final WorkerAccessContext context = new WorkerAccessContext();

    when(mockJobDao.getAllStates(any())).thenReturn(allStates);
    when(mockStateMachine.getContext(any())).thenReturn(context);

    final JobDetailResponse<?> result = stateMachineController.getDetail(jobId);

    assertEquals(
        allStates.stream().map(JobResponse::fromJob).collect(Collectors.toList()),
        result.getJobStates());
    assertEquals(context, result.getJobContext());
  }

}
