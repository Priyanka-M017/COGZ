package com.intuit.dgorchworkerapp.statemachine;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.JobContext;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.Optional;
import java.util.Set;
import lombok.Getter;
import org.junit.jupiter.api.Test;

/**
 * Test state interface's static methods.
 */
public class StateTest {

  @Test
  public void testGetRunnableStates() {
    final Set<TestJobState> states = State.getRunnableStates(TestJobState.class);

    assertTrue(states.contains(TestJobState.TEST_STATE_1));
    assertFalse(states.contains(TestJobState.TEST_STATE_2));
  }

  @Test
  public void testGetActiveStates() {
    final Set<TestJobState> states = State.getActiveStates(TestJobState.class);

    assertTrue(states.contains(TestJobState.TEST_STATE_1));
    assertFalse(states.contains(TestJobState.TEST_STATE_2));
  }

  @Test
  public void testGetStateForAction() {
    final Optional<TestJobState> state =
        State.getStateForAction(TestJobState.class, TestAction.class);

    assertTrue(state.isPresent());
    assertSame(TestJobState.TEST_STATE_1, state.get());
  }

  @Test
  public void testGetStateForActionWithSameActionOnTwoStates() {
    assertThrows(RuntimeException.class, () ->
        State.getStateForAction(TestJobStateWithSameActionOnTwoStates.class, TestAction.class));
  }

  private static class TestJobContext implements JobContext {

    @Override
    public String getId() {
      return "123456";
    }

    @Override
    public TestJobContext withId(final String id) {
      return new TestJobContext();
    }
  }

  private static class TestAction implements Action<TestJobContext> {

    @Override
    public TestJobContext onExecute(
        final Job job, final TestJobContext context
    ) {
      return null;
    }
  }

  @Getter
  private enum TestJobState implements State {
    TEST_STATE_1(
        TestAction.class,
        StateAttributes.INITIAL,
        StateAttributes.RUNNABLE,
        StateAttributes.ACTIVE),
    TEST_STATE_2(null);

    private final Class<? extends Action<? extends JobContext>> actionClass;
    private final EnumSet<StateAttributes> attributes;

    TestJobState(
        final Class<? extends Action<? extends JobContext>> actionClass,
        final StateAttributes... attributes
    ) {
      this.actionClass = actionClass;
      this.attributes = attributes.length > 0
          ? EnumSet.copyOf(Arrays.asList(attributes))
          : EnumSet.noneOf(StateAttributes.class);
    }
  }

  @Getter
  private enum TestJobStateWithSameActionOnTwoStates implements State {
    TEST_STATE_1(
        TestAction.class,
        StateAttributes.INITIAL,
        StateAttributes.RUNNABLE,
        StateAttributes.ACTIVE),
    TEST_STATE_2(TestAction.class);

    private final Class<? extends Action<? extends JobContext>> actionClass;
    private final EnumSet<StateAttributes> attributes;

    TestJobStateWithSameActionOnTwoStates(
        final Class<? extends Action<? extends JobContext>> actionClass,
        final StateAttributes... attributes
    ) {
      this.actionClass = actionClass;
      this.attributes = attributes.length > 0
          ? EnumSet.copyOf(Arrays.asList(attributes))
          : EnumSet.noneOf(StateAttributes.class);
    }
  }
}
