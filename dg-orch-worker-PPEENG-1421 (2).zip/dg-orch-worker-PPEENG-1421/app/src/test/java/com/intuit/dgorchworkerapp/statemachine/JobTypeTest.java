package com.intuit.dgorchworkerapp.statemachine;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.intuit.dgorchworkerapp.statemachine.workeraccess.WorkerAccessStateMachine;
import com.intuit.dgorchworkerapp.statemachine.workeraccessitem.WorkerAccessItemStateMachine;
import org.junit.jupiter.api.Test;

/**
 * Test for job type enum.
 */
public class JobTypeTest {

  @Test
  public void testGetJobTypeForMachine() {
    assertEquals(
        JobType.WORKER_ACCESS,
        JobType.getJobTypeForMachine(WorkerAccessStateMachine.class).orElse(null));
    assertEquals(
        JobType.WORKER_ACCESS_ITEM,
        JobType.getJobTypeForMachine(WorkerAccessItemStateMachine.class).orElse(null));
  }
}
