package com.intuit.dgorchworkerapp.rest.controllers.errors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Test;

/**
 * Test for SimpleErrorResponseBodyTest.
 */
public class SimpleErrorResponseBodyTest {
  @Test
  public void testSimpleErrorResponseBody() {
    final String msg = "this is a msg";
    final Throwable cause = mock(Throwable.class);
    final SimpleErrorResponseBody simpleErrorResponseBody =
        new SimpleErrorResponseBody(msg, cause, true);
    simpleErrorResponseBody.setMessage("new message");
    simpleErrorResponseBody.setDebugInfo("debug info");

    final SimpleErrorResponseBody simpleErrorResponseBody2 =
        new SimpleErrorResponseBody(msg, cause, true);
    simpleErrorResponseBody2.setMessage("new message");
    simpleErrorResponseBody2.setDebugInfo("debug info");

    assertTrue(simpleErrorResponseBody.equals(simpleErrorResponseBody2));
    assertTrue(simpleErrorResponseBody.canEqual(simpleErrorResponseBody2));
    assertEquals(simpleErrorResponseBody.hashCode(), simpleErrorResponseBody2.hashCode());
  }
}
