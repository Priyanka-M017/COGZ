package com.intuit.dgorchworkerapp.client.notificationservice;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.intuit.dgorchworkerapp.client.auth.SystemOfflineTicketAuthorizedClientExchangeFilterFunction;
import com.intuit.dgorchworkerapp.client.notificationservice.model.AccessNotificationEvent;
import com.intuit.dgorchworkerapp.client.notificationservice.model.NotificationEventType;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

@ExtendWith(MockitoExtension.class)
class NotificationServiceClientTest {

  @Mock
  private SystemOfflineTicketAuthorizedClientExchangeFilterFunction
      mockSystemOfflineTicketAuthorizedClientExchangeFilterFunction;

  @Test
  public void testClient() throws IOException, InterruptedException {
    final MockWebServer mockWebServer = new MockWebServer();
    mockWebServer.start();

    mockWebServer.enqueue(new MockResponse().setResponseCode(202));

    final NotificationServiceClient notificationServiceClient = new NotificationServiceClient(
        NotificationServiceProperties.builder()
            .baseUrl(mockWebServer.url("").url().toString())
            .enabled(true)
            .build(),
        WebClient.create(),
        mockSystemOfflineTicketAuthorizedClientExchangeFilterFunction);

    notificationServiceClient.sendNotification(
        NotificationEventType.WORKER_ACCESS_REQUEST_RECEIVED,
        AccessNotificationEvent.builder()
            .firstName("test")
            .persona("persona")
            .email("test@test.test")
            .build(),
        "authId",
        "tid");

    final RecordedRequest notificationRequest = mockWebServer.takeRequest(1, TimeUnit.SECONDS);
    assertEquals("/v1/events", notificationRequest.getPath());
    assertEquals("POST", notificationRequest.getMethod());

    mockWebServer.close();
  }

}
