package com.intuit.dgorchworkerapp.client.ius;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.intuit.dgorchworkerapp.client.auth.SystemOfflineTicketAuthorizedClientExchangeFilterFunction;
import com.intuit.dgorchworkerapp.client.ius.model.User;
import com.intuit.platform.integration.hats.common.AccessDeniedException;
import java.io.IOException;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

@ExtendWith(MockitoExtension.class)
class IusServiceClientTest {

  @Mock
  private SystemOfflineTicketAuthorizedClientExchangeFilterFunction
      mockSystemOfflineTicketAuthorizedClientExchangeFilterFunction;

  @Test
  void getUser() throws IOException, AccessDeniedException {
    final User user = User.builder()
        .userId("123456")
        .build();

    final MockWebServer mockWebServer = new MockWebServer();
    mockWebServer.start();

    mockWebServer.enqueue(new MockResponse()
        .setResponseCode(200)
        .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
        .setBody(new ObjectMapper().writeValueAsString(user)));

    final IusServiceClient iusServiceClient = new IusServiceClient(
        IusServiceProperties.builder()
            .baseUrl(mockWebServer.url("").url().toString())
            .build(),
        WebClient.create(),
        mockSystemOfflineTicketAuthorizedClientExchangeFilterFunction);

    final User response = iusServiceClient.getUser("123456", "tid");

    assertEquals("123456", response.getUserId());

    mockWebServer.close();
  }
}
