package com.intuit.dgorchworkerapp.client.icims;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.web.reactive.function.client.WebClient;

class IcimsServiceClientTest {

  @Disabled
  @Test
  public void test() {
    final ClientRegistrationRepository clientRegistrationRepository =
        new InMemoryClientRegistrationRepository(
            ClientRegistration.withRegistrationId("authProvider")
                .authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
                .clientId("testClient")
                .clientSecret("testSecret")
                .tokenUri("http://localhost:8888/oauth2/v1/tokens/bearer")
                .build());

    final OAuth2AuthorizedClientRepository authorizedClientRepository = null;

    final IcimsServiceClient icimsServiceClient = new IcimsServiceClient(
        new IcimsServiceProperties("http://localhost:8888", "123456"),
        clientRegistrationRepository,
        authorizedClientRepository,
        WebClient.create()
    );

    icimsServiceClient.query("test");
  }

}
