package karate;

import com.intuit.dgorchworkerapp.DgOrchWorkerApplication;
import com.intuit.karate.junit5.Karate;
import cucumber.api.CucumberOptions;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import test.ServerStart;

/**
 * Karate test.
 */
@CucumberOptions(
    plugin = {"pretty", "html:target/surefire-reports"},
    tags = {"~@ignore"})
@EnableAutoConfiguration
public class KarateTestParallel {
  public static final String[] TEST_ARGS =
      new String[] {"--spring.profiles.active=local,mock", "--server.port=0"};
  private static ServerStart server;

  /**
   * Start server before tests.
   */
  @BeforeAll
  public static void beforeClass() throws Exception {
    final String env = System.getProperty("karate.env");
    if (env == null || env.equalsIgnoreCase("local")) {
      server = new ServerStart(DgOrchWorkerApplication.class);
      server.start(TEST_ARGS, true);
      System.setProperty("karate.server.port", server.getPort() + "");
    }
  }

  /**
   * Stop server after tests.
   */
  @AfterAll
  public static void afterClass() {
    if (server != null) {
      server.stop();
    }
  }

  @Karate.Test
  public Karate testParallel() {
    return new Karate()
        .relativeTo(getClass())
        .outputCucumberJson(true);
  }
}
