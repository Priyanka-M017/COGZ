package com.intuit.dgorchworkerapp.data;

import com.intuit.dgorchworkerapp.data.models.WorkerAccessItemContext;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Data access object for work order table.
 */
@Repository
public interface WorkerAccessItemContextDao
    extends JobContextDao<WorkerAccessItemContext, String>,
    JpaRepository<WorkerAccessItemContext, String>,
    JpaSpecificationExecutor<WorkerAccessItemContext> {

  @Query("SELECT a FROM WorkerAccessItemContext a "
      + "WHERE a.parentJobId = :parentJobId AND a.assetId = :assetId")
  WorkerAccessItemContext getContextForParentAndAssetId(
      @Param("parentJobId") String parentJobId, @Param("assetId") String assetId);
}
