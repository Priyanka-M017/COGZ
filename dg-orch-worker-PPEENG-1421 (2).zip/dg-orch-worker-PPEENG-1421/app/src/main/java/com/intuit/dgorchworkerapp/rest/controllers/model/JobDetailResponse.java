package com.intuit.dgorchworkerapp.rest.controllers.model;

import java.util.List;
import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;

/**
 * Detail for job.
 *
 * @param <T> Context type
 */
@Builder
@Data
@Jacksonized
public class JobDetailResponse<T> {
  private final T jobContext;
  private final List<JobResponse> jobStates;
}
