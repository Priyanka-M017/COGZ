package com.intuit.dgorchworkerapp.data.models;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import lombok.extern.jackson.Jacksonized;

/**
 * Work order object.
 */
@Entity
@Builder(toBuilder = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@With
@Jacksonized
@ToString
public class WorkerAccessContext implements JobContext {
  @Id
  private String id;
  private String authId;
  private String verifiedIdentities;

  @Enumerated(EnumType.STRING)
  private PersonaType personaType;
  private String personaIdentifier;
  private String requestedPersonas;
  private boolean restrictedAssetsOnly;
  private String restrictedAssetIds;
}
