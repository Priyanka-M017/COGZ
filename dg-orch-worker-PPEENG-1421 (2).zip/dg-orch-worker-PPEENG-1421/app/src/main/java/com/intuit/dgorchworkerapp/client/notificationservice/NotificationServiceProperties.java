package com.intuit.dgorchworkerapp.client.notificationservice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Notification service configuration properties.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Configuration
@ConfigurationProperties(prefix = NotificationServiceProperties.PREFIX)
public class NotificationServiceProperties {
  public static final String PREFIX = "notificationservice";

  private String baseUrl;
  private boolean enabled = false;
}
