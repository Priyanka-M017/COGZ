package com.intuit.dgorchworkerapp.rest.controllers.errors;

import lombok.Data;
import org.apache.commons.lang3.exception.ExceptionUtils;

/**
 * This is the body of the every error response (status codes 400 - 599) that is
 * sent from the REST API.
 */
@Data
public class SimpleErrorResponseBody {
  private String message;
  private String debugInfo;

  // No status or cause provided, default to 500
  public SimpleErrorResponseBody(
      final String message,
      final Throwable cause,
      final boolean scrubSensitiveData
  ) {
    this.message = message;
    this.debugInfo = scrubSensitiveData ? null : ExceptionUtils.getStackTrace(cause);
  }
}
