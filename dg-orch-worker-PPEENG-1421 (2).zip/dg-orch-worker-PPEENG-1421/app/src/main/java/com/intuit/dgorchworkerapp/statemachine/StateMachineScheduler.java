package com.intuit.dgorchworkerapp.statemachine;

import static net.logstash.logback.argument.StructuredArguments.v;

import com.intuit.dgorchworkerapp.data.JobDao;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Schedule state machine runner.
 */
@Slf4j
@Component
public class StateMachineScheduler {

  private final ScheduledExecutorService scheduledExecutorService =
      Executors.newScheduledThreadPool(1);

  private final JobDao jobDao;
  private final Map<JobType, ? extends StateMachine<?, ?>> stateMachineMap;
  private final StateMachineController stateMachineController;
  private final StateMachineSchedulerConfig stateMachineSchedulerConfig;

  /**
   * State machine scheduler. Gets job type to state machine map from JobType object.
   *
   * @param jobDao Job data access object
   * @param stateMachines List of available state machines
   */
  @SuppressFBWarnings(
      value = "EI_EXPOSE_REP2",
      justification = "State machine controller must be mutable to support lazy state machine map")
  public StateMachineScheduler(
      final JobDao jobDao,
      final List<StateMachine<?, ?>> stateMachines,
      final StateMachineController stateMachineController,
      final StateMachineSchedulerConfig stateMachineSchedulerConfig
  ) {
    this.jobDao = jobDao;
    this.stateMachineController = stateMachineController;
    stateMachineMap = stateMachines.stream().collect(Collectors.toMap(
        stateMachine -> JobType.getJobTypeForMachine(stateMachine.getClass()).orElseThrow(),
        Function.identity()));
    this.stateMachineSchedulerConfig = stateMachineSchedulerConfig;
  }

  /**
   * Start scheduled state machine.
   */
  @PostConstruct
  public void start() {
    scheduledExecutorService.scheduleAtFixedRate(
        () -> {
          try {
            final long jobsProcessed = Arrays.stream(JobType.values())
                .flatMap(jobType -> {
                  final Set<String> runnableStates =
                      State.getRunnableStates(stateMachineMap.get(jobType).getStates()).stream()
                          .map(Enum::name)
                          .collect(Collectors.toSet());
                  return jobDao.getJobs(jobType, runnableStates, Instant.now()).stream();
                }).peek(job -> {
                  try {
                    stateMachineController.execute(job.getJobKey().getJobId());
                  } catch (final RuntimeException e) {
                    log.error("Error executing {}", v("job", job), e);
                  }
                }).count();
            log.info("Processed {} jobs", v("jobCount", jobsProcessed));
          } catch (final RuntimeException e) {
            log.error("Got error", e);
          }
        },
        this.stateMachineSchedulerConfig.getPeriodSeconds(),
        this.stateMachineSchedulerConfig.getPeriodSeconds(),
        TimeUnit.SECONDS);
  }

  public boolean stop() throws InterruptedException {
    scheduledExecutorService.shutdown();
    return scheduledExecutorService.awaitTermination(30, TimeUnit.SECONDS);
  }
}
