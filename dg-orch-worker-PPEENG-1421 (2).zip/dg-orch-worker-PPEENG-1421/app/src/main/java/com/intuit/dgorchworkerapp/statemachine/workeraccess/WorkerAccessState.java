package com.intuit.dgorchworkerapp.statemachine.workeraccess;

import com.intuit.dgorchworkerapp.statemachine.State;
import com.intuit.dgorchworkerapp.statemachine.StateAttributes;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.CompressionCompleteAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.CompressionPendingAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.InProgressAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.LegalHoldsCheckInProgressAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.LegalHoldsPendingAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.PendingAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.QueuedAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.WorkerAccessAction;
import java.util.Arrays;
import java.util.EnumSet;
import lombok.Getter;

/**
 * Possible job states.
 */
@Getter
public enum WorkerAccessState implements State {
  QUEUED(
      QueuedAction.class,
      StateAttributes.INITIAL,
      StateAttributes.RUNNABLE,
      StateAttributes.CANCELABLE,
      StateAttributes.ACTIVE),
  CANCELLED(
      null,
      StateAttributes.TERMINAL_SUCCESS),
  PENDING(
      PendingAction.class,
      StateAttributes.RUNNABLE,
      StateAttributes.CANCELABLE,
      StateAttributes.ACTIVE),
  LEGAL_HOLDS_PENDING(
      LegalHoldsPendingAction.class,
      StateAttributes.RUNNABLE,
      StateAttributes.CANCELABLE,
      StateAttributes.ACTIVE),
  LEGAL_HOLDS_CHECK_IN_PROGRESS(
      LegalHoldsCheckInProgressAction.class,
      StateAttributes.RUNNABLE,
      StateAttributes.CANCELABLE,
      StateAttributes.ACTIVE),
  LEGAL_HOLDS_CHECK_FAILED(
      null),
  IN_PROGRESS(
      InProgressAction.class,
      StateAttributes.RUNNABLE,
      StateAttributes.ACTIVE),
  COMPRESSION_PENDING(
      CompressionPendingAction.class,
      StateAttributes.RUNNABLE,
      StateAttributes.ACTIVE),
  COMPRESSION_COMPLETE(
      CompressionCompleteAction.class,
      StateAttributes.RUNNABLE,
      StateAttributes.ACTIVE),
  COMPRESSION_FAILED(null),
  PROCESSED(
      null,
      StateAttributes.TERMINAL_SUCCESS);

  private final Class<? extends WorkerAccessAction> actionClass;
  private final EnumSet<StateAttributes> attributes;

  WorkerAccessState(
      final Class<? extends WorkerAccessAction> actionClass,
      final StateAttributes... attributes
  ) {
    this.actionClass = actionClass;
    this.attributes = attributes.length > 0
        ? EnumSet.copyOf(Arrays.asList(attributes))
        : EnumSet.noneOf(StateAttributes.class);
  }
}
