package com.intuit.dgorchworkerapp.client.icims;

import com.intuit.cto.general.io.utils.http.IntuitCommonHeaders;
import java.util.Collections;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServletOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * Client for ICIMS service.
 */
public class IcimsServiceClient {

  private static final String OAUTH_CLIENT_REGISTRATION_ID = "authProvider";

  private final WebClient webClient;

  /**
   * Constructor.
   *
   * @param properties Client configuration
   * @param webClient WebClient to use for rest call
   */
  public IcimsServiceClient(
      final IcimsServiceProperties properties,
      final ClientRegistrationRepository registrationRepository,
      final OAuth2AuthorizedClientRepository authorizedClientManager,
      final WebClient webClient
  ) {
    final ServletOAuth2AuthorizedClientExchangeFilterFunction oauth =
        new ServletOAuth2AuthorizedClientExchangeFilterFunction(
            registrationRepository, authorizedClientManager);
    oauth.setDefaultClientRegistrationId(OAUTH_CLIENT_REGISTRATION_ID);

    this.webClient = webClient.mutate()
        .baseUrl(properties.getBaseUrl() + "/customers/{customerId}/")
        .defaultUriVariables(Collections.singletonMap("customerId", properties.getCustomerId()))
        .filter(oauth)
        .build();
  }

  /**
   * Query WIDS for network id.
   *
   * @param tid Intuit tracing id
   */
  public String query(
      final String tid
  ) {
    return webClient
        .get()
        .uri(uriBuilder -> uriBuilder.path("/search/people")
            .queryParam("searchJson", "{query}")
            .build(Collections.singletonMap("query", "{q}")))
        .header(IntuitCommonHeaders.INTUIT_HEADER_TID, tid)
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .bodyToMono(String.class)
        .block();
  }
}
