package com.intuit.dgorchworkerapp.client.ius;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * IUS client configuration properties.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Configuration
@ConfigurationProperties(prefix = IusServiceProperties.PREFIX)
public class IusServiceProperties {
  public static final String PREFIX = "iusservice";

  private String baseUrl;
}
