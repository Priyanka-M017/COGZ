package com.intuit.dgorchworkerapp.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.intuit.dgorchworkerapp.client.model.JobCallbackRequestBody;
import com.intuit.dgorchworkerapp.data.WorkerAccessItemContextDao;
import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.WorkerAccessItemContext;
import com.intuit.dgorchworkerapp.statemachine.StateMachineController;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Handles callback to orchestrator job. If callback is a response from a data manager for a
 * work order request, handleCallback will redirect the callback to the appropriate work order
 * item job.
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class CallbackHandlerService {

  private static final ObjectMapper objectMapper = new ObjectMapper();
  private final WorkerAccessItemContextDao workerAccessItemContextDao;
  private final StateMachineController stateMachineController;

  /**
   * Handles callback. Redirects callback to work order item if body contains asset id and jobId
   * is a parent of a work order item workflow.
   */
  public Job handleCallback(final String jobId, final String body) {
    try {
      final JobCallbackRequestBody requestBody =
          objectMapper.readValue(body, JobCallbackRequestBody.class);

      final WorkerAccessItemContext context =
          workerAccessItemContextDao.getContextForParentAndAssetId(jobId, requestBody.getAssetId());

      if (context != null) {
        return stateMachineController.callback(context.getId(), body);
      }
    } catch (final JsonProcessingException e) {
      log.trace("Body not of type JobCallbackRequestBody");
    }

    return stateMachineController.callback(jobId, body);
  }
}
