package com.intuit.dgorchworkerapp.rest.controllers;

import com.intuit.dgorchworkerapp.data.models.DataEntityDetails;
import com.intuit.dgorchworkerapp.data.models.DataManagerConfig;
import com.intuit.dgorchworkerapp.data.models.DataStoreDetails;
import com.intuit.dgorchworkerapp.data.models.ExtEngagementDetails;
import com.intuit.dgorchworkerapp.data.models.ManagedType;
import com.intuit.dgorchworkerapp.data.models.OnboardStage;
import com.intuit.dgorchworkerapp.repository.DataManagerRepository;
import com.intuit.dgorchworkerapp.rest.controllers.model.DataManagerConfigDto;
import com.intuit.dgorchworkerapp.service.DataManagerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.sql.Timestamp;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/** Controller to manage the data manager on-boarding/off-boarding for employee / worker. */
@Slf4j
@RequiredArgsConstructor
@RestController
public class DataManagerController {

  private final DataManagerService dataManagerService;
  private final DataManagerRepository dataManagerRepository;
  final Timestamp timestamp = new Timestamp(System.currentTimeMillis());

  /**
   * Method to get the data manager on-boarding details for employee / worker.
   *
   * @param assetId asset id
   * @return data manger details for that particular asset
   */
  @RequestMapping(method = RequestMethod.GET, path = "/v1/resources/datamanager/{assetId}")
  @Operation(
      description = "Get data manager on-boarding details",
      summary = "Get data manager on-boarding details")
  @ApiResponses(
      value = {
        @ApiResponse(responseCode = "200", description = "SUCCESS"),
        @ApiResponse(responseCode = "404", description = "Resource Not Found"),
        @ApiResponse(responseCode = "201", description = "Created"),
        @ApiResponse(responseCode = "401", description = "Unauthorized"),
        @ApiResponse(responseCode = "400", description = "Bad request")
      })
  public DataManagerConfigDto getAssetById(@PathVariable("assetId") final int assetId) {
    log.info("Got request for getAssetById {}" + assetId);
    return dataManagerService.getAssetById(assetId);
  }

  /**
   * Method to save the data manager on-boarding details for employee / worker.
   *
   * @param dataManagerConfigDto dmConfigDto
   * @return data manger details for that particular asset
   */
  @RequestMapping(method = RequestMethod.POST, path = "/v1/resources/datamanager")
  @Operation(
      description = "Save data manager on-boarding details",
      summary = "Save data manager on-boarding details")
  @ApiResponses(
      value = {
        @ApiResponse(responseCode = "200", description = "SUCCESS"),
        @ApiResponse(responseCode = "404", description = "Resource Not Found"),
        @ApiResponse(responseCode = "201", description = "Created"),
        @ApiResponse(responseCode = "401", description = "Unauthorized"),
        @ApiResponse(responseCode = "400", description = "Bad request")
      })
  public ResponseEntity saveDataManagerConfigDetails(
      @RequestBody final DataManagerConfigDto dataManagerConfigDto) {
    log.info("Got request for saveDataManagerConfigDetails {}" + dataManagerConfigDto);

    if (dataManagerService.existsById((int) dataManagerConfigDto.getAssetId())) {
      return ResponseEntity.status(HttpStatus.BAD_REQUEST)
          .body("Asset Id " + dataManagerConfigDto.getAssetId() + " already exists.");
    } else {
      final long assetId = dataManagerConfigDto.getAssetId();

      final List<ManagedType> managedTypeList =
          dataManagerConfigDto.getManagedTypeList().stream()
              .map(
                  managedType -> {
                    managedType.setAssetId(assetId);
                    managedType.setManagedTypeId(managedType.getManagedTypeId());
                    managedType.setManagedTypeValue(managedType.getManagedTypeValue());
                    managedType.setCreatedDate(timestamp);
                    managedType.setDeletedDate(null);
                    return managedType;
                  })
              .collect(Collectors.toList());

      final List<DataStoreDetails> dataStoreDetailsList =
          dataManagerConfigDto.getDataStoreDetails().stream()
              .map(
                  dataStoreDetails -> {
                    dataStoreDetails.setAssetId(assetId);
                    dataStoreDetails.setDataStoreId(dataStoreDetails.getDataStoreId());
                    dataStoreDetails.setDataStoreValue(dataStoreDetails.getDataStoreValue());
                    dataStoreDetails.setCreatedDate(timestamp);
                    dataStoreDetails.setDeletedDate(null);
                    return dataStoreDetails;
                  })
              .collect(Collectors.toList());

      final List<DataEntityDetails> dataEntityDetailsList =
          dataManagerConfigDto.getDataEntityDetails().stream()
              .map(
                  dataEntityDetails -> {
                    dataEntityDetails.setAssetId(assetId);
                    dataEntityDetails.setDataEntityId(dataEntityDetails.getDataEntityId());
                    dataEntityDetails.setDataEntityValue(dataEntityDetails.getDataEntityValue());
                    dataEntityDetails.setCreatedDate(timestamp);
                    dataEntityDetails.setDeletedDate(null);
                    return dataEntityDetails;
                  })
              .collect(Collectors.toList());

      final List<ExtEngagementDetails> extEngagementDetailsList =
          dataManagerConfigDto.getExtEngagementDetails().stream()
              .map(
                  extEngagementDetails -> {
                    extEngagementDetails.setAssetId(assetId);
                    extEngagementDetails.setExtEngagementId(
                        extEngagementDetails.getExtEngagementId());
                    extEngagementDetails.setExtEngagementValue(
                        extEngagementDetails.getExtEngagementValue());
                    extEngagementDetails.setCreatedDate(timestamp);
                    extEngagementDetails.setDeletedDate(null);
                    return extEngagementDetails;
                  })
              .collect(Collectors.toList());

      final DataManagerConfig dataManagerConfig =
          DataManagerConfig.builder()
              .assetId(dataManagerConfigDto.getAssetId())
              .onboardStage(
                  dataManagerConfigDto.getOnboardStage() != null
                      ? dataManagerConfigDto.getOnboardStage()
                      : OnboardStage.NONE)
              .createdDate(timestamp)
              .deletedDate(null)
              .managedTypeDetails(managedTypeList)
              .dataStoreDetails(dataStoreDetailsList)
              .dataEntityDetails(dataEntityDetailsList)
              .extEngagementDetails(extEngagementDetailsList)
              .build();

      dataManagerService.saveOrUpdate(dataManagerConfig);
      return new ResponseEntity<>(dataManagerConfigDto, HttpStatus.OK);
    }
  }
}
