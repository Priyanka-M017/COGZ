package com.intuit.dgorchworkerapp.statemachine.workeraccessitem.actions;

import com.intuit.dgorchworkerapp.data.models.WorkerAccessItemContext;
import com.intuit.dgorchworkerapp.statemachine.Action;

/**
 * State machine action for worker access item state machine.
 */
public interface WorkerAccessItemAction extends Action<WorkerAccessItemContext> {
}
