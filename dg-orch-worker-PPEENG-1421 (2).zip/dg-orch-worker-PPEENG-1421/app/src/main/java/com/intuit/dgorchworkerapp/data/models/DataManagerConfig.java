package com.intuit.dgorchworkerapp.data.models;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity to capture the details of the data manager on-boarding / off-boarding.
 */
@Entity
@Table
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DataManagerConfig {

  @OneToMany(cascade = CascadeType.ALL)
  @JoinColumn(name = "fk_assetId", referencedColumnName = "assetId")
  List<ManagedType> managedTypeDetails = new ArrayList<>();
  @OneToMany(cascade = CascadeType.ALL)
  @JoinColumn(name = "fk_assetId", referencedColumnName = "assetId")
  List<DataStoreDetails> dataStoreDetails = new ArrayList<>();
  @OneToMany(cascade = CascadeType.ALL)
  @JoinColumn(name = "fk_assetId", referencedColumnName = "assetId")
  List<DataEntityDetails> dataEntityDetails = new ArrayList<>();
  @OneToMany(cascade = CascadeType.ALL)
  @JoinColumn(name = "fk_assetId", referencedColumnName = "assetId")
  List<ExtEngagementDetails> extEngagementDetails = new ArrayList<>();
  @Id @Column private long assetId;
  @Column private OnboardStage onboardStage;
  @Column private Timestamp createdDate;
  @Column private Timestamp deletedDate;
}
