package com.intuit.dgorchworkerapp.statemachine;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Configurations for the state machine scheduler.
 */
@Data
@Configuration
@ConfigurationProperties(prefix = StateMachineSchedulerConfig.PREFIX)
public class StateMachineSchedulerConfig {
  static final String PREFIX = "statemachine.scheduler";

  private int periodSeconds;
}
