package com.intuit.dgorchworkerapp.client.notificationservice.model;

import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;

/**
 * Notification event request metadata.
 */
@Builder
@Data
@Jacksonized
public class NotificationEventMetadata {
  private final String authId;
  private final String createdDate;
  private final String intuitTid;
  private final String locale;
}
