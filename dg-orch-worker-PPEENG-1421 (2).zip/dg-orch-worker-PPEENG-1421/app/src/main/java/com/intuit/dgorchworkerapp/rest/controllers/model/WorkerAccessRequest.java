package com.intuit.dgorchworkerapp.rest.controllers.model;

import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;

/**
 * API request for worker access requests.
 */
@Builder
@Data
@Jacksonized
public class WorkerAccessRequest {
  private final String authId;
  private final String verifiedIdentities;
  private final String personaType;
  private final String personaIdentifier;
  private final String requestedPersonas;
  private final boolean restrictedAssetsOnly;
  private final String restrictedAssetIds;
}
