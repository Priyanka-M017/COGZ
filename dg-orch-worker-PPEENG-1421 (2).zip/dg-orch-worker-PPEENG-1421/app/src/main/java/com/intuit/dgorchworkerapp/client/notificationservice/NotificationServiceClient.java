package com.intuit.dgorchworkerapp.client.notificationservice;

import static net.logstash.logback.argument.StructuredArguments.kv;
import static net.logstash.logback.argument.StructuredArguments.v;

import com.intuit.cto.general.io.utils.http.IntuitCommonHeaders;
import com.intuit.dgorchworkerapp.client.auth.SystemOfflineTicketAuthorizedClientExchangeFilterFunction;
import com.intuit.dgorchworkerapp.client.notificationservice.exception.NotificationServiceErrorException;
import com.intuit.dgorchworkerapp.client.notificationservice.model.EventData;
import com.intuit.dgorchworkerapp.client.notificationservice.model.NotificationEventBase;
import com.intuit.dgorchworkerapp.client.notificationservice.model.NotificationEventMetadata;
import com.intuit.dgorchworkerapp.client.notificationservice.model.NotificationEventType;
import java.time.Instant;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

/**
 * One Intuit Notification Service is used to send communication to users such as emails.
 */
@Slf4j
@Component
public class NotificationServiceClient {

  private final WebClient webClient;
  private final boolean isEnabled;

  /**
   * Constructor.
   *
   * @param properties Client configuration
   * @param webClient WebClient to use for rest call
   */
  public NotificationServiceClient(
      final NotificationServiceProperties properties,
      final WebClient webClient,
      final SystemOfflineTicketAuthorizedClientExchangeFilterFunction authFilterFunction
  ) {
    this.isEnabled = properties.isEnabled();
    this.webClient = webClient.mutate()
        .baseUrl(properties.getBaseUrl())
        .filter(authFilterFunction)
        .build();
  }

  /**
   * Send notification to customer.
   *
   * @param notificationEventType Type of notification to send
   * @param eventData Data of event
   * @param authId Auth id of user triggering the event
   * @param tid Intuit tid
   */
  public void sendNotification(
      final NotificationEventType notificationEventType,
      final EventData eventData,
      final String authId,
      final String tid
  ) {
    if (!isEnabled) {
      log.info("Notifications disabled");
      return;
    }

    final NotificationEventBase<?> notificationEventBase = NotificationEventBase.builder()
        .name(notificationEventType.getEventName())
        .sourceServiceName(notificationEventType.getSourceServiceName())
        .sourceObjectId(UUID.randomUUID().toString())
        .sourceObjectType(notificationEventType.getSourceObjectType())
        .eventData(eventData)
        .eventMetaData(NotificationEventMetadata.builder()
            .authId(authId)
            .createdDate(Instant.now().toString())
            .intuitTid(tid)
            .build())
        .build();

    log.info("Sending event {} {}",
        v("objectId", notificationEventBase.getName()),
        kv("sourceObjectId", notificationEventBase.getSourceObjectId()));

    webClient
        .post()
        .uri("v1/events")
        .header(IntuitCommonHeaders.INTUIT_HEADER_TID, tid)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(notificationEventBase)
        .retrieve()
        .onRawStatus(
            code -> code >= 400,
            response -> Mono.error(
                new NotificationServiceErrorException("Got code " + response.rawStatusCode())))
        .toBodilessEntity()
        .block();
  }
}
