package com.intuit.dgorchworkerapp.client.wids;

import com.intuit.cto.general.io.utils.http.IntuitCommonHeaders;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServletOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * Client for WIDS service.
 */
@Slf4j
@Component
public class WidsServiceClient {

  private static final String OAUTH_CLIENT_REGISTRATION_ID = "authProvider";

  private final WebClient webClient;

  /**
   * Constructor.
   *
   * @param properties Client configuration
   * @param webClient WebClient to use for rest call
   */
  public WidsServiceClient(
      final WidsServiceProperties properties,
      final ClientRegistrationRepository registrationRepository,
      final OAuth2AuthorizedClientRepository authorizedClientManager,
      final WebClient webClient
  ) {
    final ServletOAuth2AuthorizedClientExchangeFilterFunction oauth =
        new ServletOAuth2AuthorizedClientExchangeFilterFunction(
            registrationRepository, authorizedClientManager);
    oauth.setDefaultClientRegistrationId(OAUTH_CLIENT_REGISTRATION_ID);

    this.webClient = webClient.mutate()
        .baseUrl(properties.getBaseUrl())
        .filter(oauth)
        .build();
  }

  /**
   * Query WIDS for network id.
   *
   * @param networkId Network id to query
   * @param tid Intuit tracing id
   */
  public String query(
      final String networkId,
      final String tid
  ) {
    return webClient
        .get()
        .uri(uriBuilder -> uriBuilder.path("/v1/workerData/query")
            .queryParam("networkId", networkId)
            .build())
        .header(IntuitCommonHeaders.INTUIT_HEADER_TID, tid)
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .bodyToMono(String.class)
        .block();
  }
}
