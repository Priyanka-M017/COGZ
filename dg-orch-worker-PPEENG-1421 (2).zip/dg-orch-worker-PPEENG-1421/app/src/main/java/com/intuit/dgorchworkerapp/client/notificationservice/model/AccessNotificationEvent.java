package com.intuit.dgorchworkerapp.client.notificationservice.model;

import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;

/**
 * Notification event request object.
 */
@Builder
@Data
@Jacksonized
public class AccessNotificationEvent implements EventData {
  private final String email;
  private final String persona;
  private final String firstName;
}
