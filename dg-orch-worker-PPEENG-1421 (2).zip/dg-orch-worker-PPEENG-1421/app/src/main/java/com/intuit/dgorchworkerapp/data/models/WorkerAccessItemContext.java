package com.intuit.dgorchworkerapp.data.models;

import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import lombok.extern.jackson.Jacksonized;

/**
 * Worker access item context object.
 */
@Entity
@Builder(toBuilder = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@With
@Jacksonized
@ToString
public class WorkerAccessItemContext implements JobContext {
  @Id
  private String id;
  private String parentJobId;
  private String assetId;
}
