package com.intuit.dgorchworkerapp.client.notificationservice.model;

/**
 * Interface of event data types.
 */
public interface EventData {
}
