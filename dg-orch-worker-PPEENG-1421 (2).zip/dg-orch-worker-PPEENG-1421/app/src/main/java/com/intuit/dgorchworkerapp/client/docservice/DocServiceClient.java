package com.intuit.dgorchworkerapp.client.docservice;

/**
 * Client for doc service.
 */
public class DocServiceClient {
}
