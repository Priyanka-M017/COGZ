package com.intuit.dgorchworkerapp.rest.controllers;

import static net.logstash.logback.argument.StructuredArguments.v;

import com.intuit.dgorchworkerapp.rest.controllers.model.JobResponse;
import com.intuit.dgorchworkerapp.service.CallbackHandlerService;
import com.intuit.platform.jsk.security.iam.authn.IntuitTicketAuthentication;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * Rest API to control state machine.
 */
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping(value = "v1/job", produces = {MediaType.APPLICATION_JSON_VALUE})
@Tag(name = "job")
public class JobController {

  private final CallbackHandlerService callbackHandlerService;

  /**
   * Callback to job.
   */
  @RequestMapping(method = RequestMethod.POST, path = "{jobId}/callback")
  @Operation(
      description = "Submit worker access job for processing",
      summary = "Submit worker access job",
      security = {@SecurityRequirement(name = "privateAuthUser", scopes = {})}
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Request submitted"),
      @ApiResponse(responseCode = "400", description = "Bad request")
  })
  public JobResponse executeWorkOrder(
      @Parameter(required = true) @PathVariable final String jobId,
      @RequestBody final String body,
      @Parameter(hidden = true) final IntuitTicketAuthentication principal
  ) {
    log.info("Got request for {}", v("principal", principal != null ? principal.getName() : null));

    return JobResponse.fromJob(callbackHandlerService.handleCallback(jobId, body));
  }
}
