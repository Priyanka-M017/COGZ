package com.intuit.dgorchworkerapp.statemachine.workeraccess.actions;

import static net.logstash.logback.argument.StructuredArguments.v;

import com.intuit.dgorchworkerapp.client.ius.IusServiceClient;
import com.intuit.dgorchworkerapp.client.ius.model.User;
import com.intuit.dgorchworkerapp.client.notificationservice.NotificationServiceClient;
import com.intuit.dgorchworkerapp.client.notificationservice.model.AccessNotificationEvent;
import com.intuit.dgorchworkerapp.client.notificationservice.model.NotificationEventType;
import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.WorkerAccessContext;
import com.intuit.dgorchworkerapp.statemachine.State;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.WorkerAccessState;
import com.intuit.platform.integration.hats.common.AccessDeniedException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Action class for worker access queued state.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class QueuedAction implements WorkerAccessAction {

  private final IusServiceClient iusServiceClient;
  private final NotificationServiceClient notificationServiceClient;

  @Override
  public WorkerAccessContext onExecute(
      final Job job,
      final WorkerAccessContext context
  ) throws AccessDeniedException {
    log.info("Run {} for {}",
        v("state", State.getStateForAction(WorkerAccessState.class, this.getClass())),
        v("context", context));
    final User user = iusServiceClient.getUser(context.getAuthId(), job.getJobKey().getJobId());

    notificationServiceClient.sendNotification(
        NotificationEventType.WORKER_ACCESS_REQUEST_RECEIVED,
        AccessNotificationEvent.builder()
            .email(user.getEmail().getAddress())
            .firstName(user.getUsername())
            .persona(context.getPersonaType().toString())
            .build(),
        context.getAuthId(),
        job.getJobKey().getJobId()
    );

    log.info("Request received notification sent");

    return context;
  }
}
