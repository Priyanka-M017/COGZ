package com.intuit.dgorchworkerapp.client.wids;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * WIDS service configuration properties.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Configuration
@ConfigurationProperties(prefix = WidsServiceProperties.PREFIX)
public class WidsServiceProperties {
  public static final String PREFIX = "widsservice";

  private String baseUrl;
}
