package com.intuit.dgorchworkerapp.statemachine.workeraccess.actions;

import com.intuit.dgorchworkerapp.data.models.WorkerAccessContext;
import com.intuit.dgorchworkerapp.statemachine.Action;

/**
 * State machine action for worker access state machine.
 */
public interface WorkerAccessAction extends Action<WorkerAccessContext> {
}
