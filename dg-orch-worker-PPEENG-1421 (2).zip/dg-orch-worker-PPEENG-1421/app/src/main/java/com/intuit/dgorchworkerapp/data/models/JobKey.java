package com.intuit.dgorchworkerapp.data.models;

import java.io.Serializable;
import javax.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Composite key for Job table.
 */
@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobKey implements Serializable {
  private String jobId;
  private int record;
}
