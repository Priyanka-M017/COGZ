package com.intuit.dgorchworkerapp.client.notificationservice.model;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Repository of types of notifications available to send.
 */
@Getter
@RequiredArgsConstructor
public enum NotificationEventType {
  WORKER_ACCESS_REQUEST_RECEIVED(
      "candidate-flow-download-request-recieved-event-TBD",
      "DG2_Worker-TBD",
      "candidate-flow-download-request-recieved-event",
      AccessNotificationEvent.class);

  private final String eventName;
  private final String sourceServiceName;
  private final String sourceObjectType;
  private final Class<? extends EventData> eventDataType;
}
