package com.intuit.dgorchworkerapp.statemachine.workeraccess.actions;

import static net.logstash.logback.argument.StructuredArguments.v;

import com.intuit.dgorchworkerapp.data.WorkerAccessItemContextDao;
import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.WorkerAccessContext;
import com.intuit.dgorchworkerapp.data.models.WorkerAccessItemContext;
import com.intuit.dgorchworkerapp.statemachine.JobType;
import com.intuit.dgorchworkerapp.statemachine.State;
import com.intuit.dgorchworkerapp.statemachine.StateMachineController;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.WorkerAccessState;
import com.intuit.dgworker.entity.DgWorkerEvent;
import com.intuit.dgworker.entity.EventType;
import java.util.Collections;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

/**
 * Action class for worker access pending state.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class PendingAction implements WorkerAccessAction {

  private final KafkaTemplate<String, DgWorkerEvent> kafkaTemplate;
  private final StateMachineController stateMachineController;
  private final WorkerAccessItemContextDao workerAccessItemContextDao;

  @Override
  public WorkerAccessContext onExecute(
      final Job job,
      final WorkerAccessContext context
  ) {
    log.info("Run {} for {}",
        v("state", State.getStateForAction(WorkerAccessState.class, this.getClass())),
        v("context", context));

    final WorkerAccessItemContext childJobContext =
        workerAccessItemContextDao.getContextForParentAndAssetId(
            job.getJobKey().getJobId(),
            "4038620558795136245");
    if (childJobContext == null) {
      stateMachineController.submit(
          JobType.WORKER_ACCESS_ITEM,
          WorkerAccessItemContext.builder()
              .assetId("4038620558795136245")
              .parentJobId(job.getJobKey().getJobId())
              .build(),
          job.getJobKey().getJobId());
    } else {
      log.warn("Skip creating child workflow due to existing workflow.");
    }

    kafkaTemplate.sendDefault(
        DgWorkerEvent.builder()
            .jobId(job.getJobKey().getJobId())
            .eventType(EventType.WORKER_ACCESS.toString())
            .assetIds(Collections.singleton("4038620558795136245"))
            .tid(UUID.randomUUID().toString())
            .build()
    );

    return context;
  }
}
