package com.intuit.dgorchworkerapp.client.devservice;

/**
 * Client for dev service.
 */
public class DevServiceClient {
}
