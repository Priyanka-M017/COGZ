/**
 * Copyright 2015-2020 Intuit Inc. All rights reserved. Unauthorized reproduction is a violation of
 * applicable law. This material contains certain confidential or proprietary information and trade
 * secrets of Intuit Inc.
 */

package com.intuit.dgorchworkerapp;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

/** Application class for dg worker orchestration. */
@OpenAPIDefinition(
    servers = {@Server(url = "https://dgorchworker-qal.api.intuit.com/"), @Server(url = "/")})
@SecurityScheme(
    name = "privateAuthUser",
    paramName = "Authorization",
    type = SecuritySchemeType.APIKEY,
    in = SecuritySchemeIn.HEADER)
@SpringBootApplication
public class DgOrchWorkerApplication {

  public static ConfigurableApplicationContext run(final String[] args) {
    return SpringApplication.run(DgOrchWorkerApplication.class, args);
  }

  public static void main(final String[] args) {
    run(args); // NOSONAR
  }
}
