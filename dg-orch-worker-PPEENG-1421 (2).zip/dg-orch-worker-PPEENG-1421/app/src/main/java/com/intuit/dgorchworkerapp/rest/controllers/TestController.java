package com.intuit.dgorchworkerapp.rest.controllers;

import static com.intuit.cto.general.io.utils.http.IntuitCommonHeaders.INTUIT_ATTRIBUTE_TID;

import com.intuit.dgorchworkerapp.client.ius.IusServiceClient;
import com.intuit.dgorchworkerapp.client.ius.model.User;
import com.intuit.platform.integration.hats.common.AccessDeniedException;
import com.intuit.platform.jsk.security.iam.authn.IntuitTicketAuthentication;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Test API to test stuff.
 */
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping(value = "v1/test", produces = {MediaType.APPLICATION_JSON_VALUE})
@Tag(name = "test")
public class TestController {

  private final IusServiceClient iusServiceClient;

  /**
   * Get active work orders current state.
   *
   * @param principal Intuit principal
   * @return List of jobs which are runnable
   */
  @RequestMapping(
      method = RequestMethod.GET,
      path = "notify",
      produces = {MediaType.APPLICATION_JSON_VALUE}
  )
  @Operation(
      description = "Test notification",
      summary = "Test notification"
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "400", description = "Bad request")
  })
  public User testNotification(
      @Parameter(required = true) @RequestParam final String authId,
      @Parameter(hidden = true) @RequestAttribute(INTUIT_ATTRIBUTE_TID) final String tid,
      @Parameter(hidden = true) final IntuitTicketAuthentication principal
  ) throws AccessDeniedException {
    return iusServiceClient.getUser(authId, tid);
  }
}
