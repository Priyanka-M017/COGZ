package com.intuit.dgorchworkerapp.data.models;

/**
 * ENUM for the Environment to which the data manager is on-boarded.
 */
public enum OnboardStage {
  NONE,
  E2E,
  PRODUCTION
}
