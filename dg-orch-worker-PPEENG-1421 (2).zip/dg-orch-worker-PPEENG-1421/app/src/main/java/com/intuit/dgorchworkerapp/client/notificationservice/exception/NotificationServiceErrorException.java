package com.intuit.dgorchworkerapp.client.notificationservice.exception;

/**
 * Unable to complete call to notification service.
 */
public class NotificationServiceErrorException extends RuntimeException {

  public NotificationServiceErrorException(final String message) {
    super(message);
  }
}
