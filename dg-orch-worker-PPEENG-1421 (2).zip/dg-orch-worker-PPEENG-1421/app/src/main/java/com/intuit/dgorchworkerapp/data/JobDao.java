package com.intuit.dgorchworkerapp.data;

import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.JobKey;
import com.intuit.dgorchworkerapp.statemachine.JobType;
import java.time.Instant;
import java.util.List;
import java.util.Set;
import javax.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Data access object for Job table.
 */
@Repository
public interface JobDao
    extends JpaRepository<Job, JobKey>, JpaSpecificationExecutor<Job> {

  @Query("SELECT a FROM Job a WHERE a.jobKey.jobId = :jobId ORDER BY a.jobKey.record")
  List<Job> getAllStates(@Param("jobId") String jobId);

  @Query("SELECT a FROM Job a "
      + "LEFT JOIN Job b ON a.jobKey.jobId = b.jobKey.jobId AND a.jobKey.record < b.jobKey.record "
      + "WHERE b.jobKey.record is NULL AND a.jobKey.jobId = :jobId")
  @Lock(LockModeType.PESSIMISTIC_WRITE)
  Job getCurrentState(@Param("jobId") String jobId);

  @Query("SELECT a FROM Job a "
      + "LEFT JOIN Job b ON a.jobKey.jobId = b.jobKey.jobId AND a.jobKey.record < b.jobKey.record "
      + "WHERE b.jobKey.record is NULL AND a.parentJobId = :parentJobId")
  List<Job> getChildJobs(@Param("parentJobId") String parentJobId);

  @Query("SELECT a FROM Job a "
      + "LEFT JOIN Job b ON a.jobKey.jobId = b.jobKey.jobId AND a.jobKey.record < b.jobKey.record "
      + "WHERE b.jobKey.record is NULL "
      + "AND a.jobType = :jobType AND a.state in (:states) AND a.until < :until")
  List<Job> getJobs(
      @Param("jobType") JobType jobType,
      @Param("states") Set<String> states,
      @Param("until") Instant until);

  @Query("SELECT a FROM Job a "
      + "LEFT JOIN Job b ON a.jobKey.jobId = b.jobKey.jobId AND a.jobKey.record < b.jobKey.record "
      + "WHERE b.jobKey.record is NULL AND a.jobType = :jobType AND a.state in (:states)")
  List<Job> getJobs(@Param("jobType") JobType jobType, @Param("states") Set<String> states);

  @Query("SELECT a FROM Job a "
      + "LEFT JOIN Job b ON a.jobKey.jobId = b.jobKey.jobId AND a.jobKey.record < b.jobKey.record "
      + "WHERE b.jobKey.record is NULL "
      + "AND a.jobType = :jobType AND a.state in (:states) AND a.since >= :since")
  List<Job> getJobsSince(
      @Param("jobType") JobType jobType,
      @Param("states") Set<String> states,
      @Param("since") Instant since);
}
