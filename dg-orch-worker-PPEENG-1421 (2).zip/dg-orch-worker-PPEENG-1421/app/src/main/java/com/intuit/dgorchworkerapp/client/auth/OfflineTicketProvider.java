package com.intuit.dgorchworkerapp.client.auth;

import com.intuit.platform.integration.hats.client.request.GetAuthHeaderForIdentityAuthorizedOfflineTicketRequestBuilder;
import com.intuit.platform.integration.hats.client.request.GetAuthHeaderForSystemOfflineTicketRequestBuilder;
import com.intuit.platform.integration.hats.common.InvalidRequestException;
import com.intuit.platform.integration.hats.common.OfflineTicketAuthorizationHeader;
import com.intuit.platform.integration.iamticket.client.IAMOfflineTicketClient;
import com.intuit.platform.jsk.security.iam.autoconfig.IntuitSecurityProperties;
import java.time.Duration;
import java.util.Collections;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Offline ticket provider.
 */
@Slf4j
@Component
public class OfflineTicketProvider {

  // Minimum value is 1 hour
  private static final Duration MAX_TICKET_LIFE = Duration.ofHours(1);

  private final IAMOfflineTicketClient iamOfflineTicketClient;
  private final String appId;
  private final String appSecret;
  private final String intuitAssetId;
  private final String sysUserName;
  private final String sysPassword;
  private final String originatingIp;

  /**
   * Construct OfflineTicketProvider object.
   *
   * @param iamOfflineTicketClient Client used to fetch tickets
   * @param intuitSecurityProperties Intuit security properties
   * @param intuitOfflineTicketProperties Intuit offline ticket properties
   */
  @Autowired
  public OfflineTicketProvider(
      final IAMOfflineTicketClient iamOfflineTicketClient,
      final IntuitSecurityProperties intuitSecurityProperties,
      final IntuitOfflineTicketProperties intuitOfflineTicketProperties
  ) {
    this.iamOfflineTicketClient = iamOfflineTicketClient;
    this.appId = intuitSecurityProperties.getAppId();
    this.appSecret = intuitSecurityProperties.getAppSecret();
    this.intuitAssetId = intuitOfflineTicketProperties.getIntuitAssetId();
    this.sysUserName = intuitOfflineTicketProperties.getSysUserName();
    this.sysPassword = intuitOfflineTicketProperties.getSysPassword();
    this.originatingIp = intuitOfflineTicketProperties.getOriginatingIp();
  }

  /**
   * Get system offline ticket.
   *
   * @return Authorization header entry
   * @throws InvalidRequestException Unable to acquire offline ticket
   */
  public String getOfflineTicketHeader() throws InvalidRequestException {
    return generateSystemOfflineTicket().getAuthorizationHeader();
  }

  /**
   * Get user offline ticket.
   *
   * @return Authorization header entry
   * @throws InvalidRequestException Unable to acquire offline ticket
   */
  public String getOfflineTicketHeader(
      final String authId,
      final String purpose
  ) throws InvalidRequestException {
    return generateUserOfflineTicket(authId, purpose).getAuthorizationHeader();
  }

  private OfflineTicketAuthorizationHeader generateSystemOfflineTicket()
      throws InvalidRequestException {
    return iamOfflineTicketClient.getAuthHeaderForSystemOfflineTicket(
        new GetAuthHeaderForSystemOfflineTicketRequestBuilder()
            .setAppId(appId)
            .setAppSecret(appSecret)
            .setAssetId(intuitAssetId)
            .setUsername(sysUserName)
            .setPassword(sysPassword)
            .setIp(originatingIp)
            .setMaxLifeSeconds((int) MAX_TICKET_LIFE.getSeconds())
            .setTransactionId(UUID.randomUUID().toString())
            .build()
    );
  }

  private OfflineTicketAuthorizationHeader generateUserOfflineTicket(
      final String authId,
      final String purpose
  ) throws InvalidRequestException {
    return iamOfflineTicketClient.getAuthHeaderForIdentityAuthorizedOfflineTicket(
        new GetAuthHeaderForIdentityAuthorizedOfflineTicketRequestBuilder()
            .setAppId(appId)
            .setAppSecret(appSecret)
            .setAssetId(intuitAssetId)
            .setPurposes(Collections.singletonList(purpose))
            .setIdentityId(authId)
            .setIp(originatingIp)
            .setTransactionId(UUID.randomUUID().toString())
            .build()
    );
  }
}
