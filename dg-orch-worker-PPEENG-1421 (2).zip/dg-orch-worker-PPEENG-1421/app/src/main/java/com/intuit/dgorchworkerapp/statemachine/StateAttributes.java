package com.intuit.dgorchworkerapp.statemachine;

/**
 * State attributes for state scheduling.
 */
public enum StateAttributes {
  INITIAL,
  TERMINAL_SUCCESS,
  TERMINAL_FAILED,
  RUNNABLE,
  ACTIVE,
  CANCELABLE
}
