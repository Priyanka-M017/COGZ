package com.intuit.dgorchworkerapp.rest.controllers.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.intuit.dgorchworkerapp.data.models.DataEntityDetails;
import com.intuit.dgorchworkerapp.data.models.DataStoreDetails;
import com.intuit.dgorchworkerapp.data.models.ExtEngagementDetails;
import com.intuit.dgorchworkerapp.data.models.ManagedType;
import com.intuit.dgorchworkerapp.data.models.OnboardStage;
import java.sql.Timestamp;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;

/**
 * API Response Object for the DataManagerConfig Database Object.
 */
@Data
@AllArgsConstructor
@Builder
@Jacksonized
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DataManagerConfigDto {

  private final long assetId;
  private final List<ManagedType> managedTypeList;
  private final OnboardStage onboardStage;
  private final List<DataStoreDetails> dataStoreDetails;
  private final List<DataEntityDetails> dataEntityDetails;
  private final List<ExtEngagementDetails> extEngagementDetails;
  private final Timestamp createdDate;
  private final Timestamp deletedDate;

}
