package com.intuit.dgorchworkerapp.rest.controllers.exceptions;

/**
 * Exception for request violations.
 */
public class WorkerAccessConstraintViolationException extends RuntimeException {

  /**
   * Construct with both a {@code String} message and a {@code Throwable}
   * cause. The {@code message} is returned by the inherited
   * {@code Throwable.getMessage}. The cause that is returned by the inherited
   * {@code Throwable.getCause}.
   *
   * @param message
   *            the message that is returned by the inherited
   *            {@code Throwable.getMessage}
   * @param cause
   *            the cause that is returned by the inherited
   *            {@code Throwable.getCause}
   */
  public WorkerAccessConstraintViolationException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
