package com.intuit.dgorchworkerapp.data;

import java.util.Optional;

/**
 * Interface to job contexts.
 *
 * @param <T> Context type
 * @param <K> Key type
 */
public interface JobContextDao<T, K> {
  T save(T entity);

  Optional<T> findById(K id);
}
