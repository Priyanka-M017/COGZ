package com.intuit.dgorchworkerapp.kafka;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.intuit.eventbus.Serializer;
import com.intuit.eventbus.exceptions.SerializerViolationException;
import com.intuit.eventbus.message.SchemaContext;

/**
 * Serialize generic object.
 *
 * @param <T> Type of object to serialize
 */
public class ObjectSerializer<T> implements Serializer<T> {

  final ObjectMapper objectMapper = JsonMapper.builder().build();

  @Override
  public byte[] apply(final T t, final SchemaContext<T> schemaContext) {
    try {
      return objectMapper.writeValueAsBytes(t);
    } catch (final JsonProcessingException e) {
      throw new SerializerViolationException("Cannot serialize message", e);
    }
  }
}
