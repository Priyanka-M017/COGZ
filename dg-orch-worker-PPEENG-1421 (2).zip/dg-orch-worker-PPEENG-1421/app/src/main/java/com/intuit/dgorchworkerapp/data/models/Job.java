package com.intuit.dgorchworkerapp.data.models;

import com.intuit.dgorchworkerapp.statemachine.JobType;
import com.intuit.dgorchworkerapp.statemachine.State;
import java.time.Instant;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Current job execution.
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Job {
  @EmbeddedId
  private JobKey jobKey;

  @Enumerated(EnumType.STRING)
  private JobType jobType;
  private String parentJobId;
  private String state;
  private Instant since;
  private Instant until;
  private String description;

  public Job newState(final Enum<? extends State> newState) {
    return newState(newState, Instant.now());
  }

  public Job newState(final Enum<? extends State> newState, final String description) {
    return newState(newState, Instant.now(), description);
  }

  public Job newState(final Enum<? extends State> newState, final Instant until) {
    return newState(newState, until, "");
  }

  /**
   * Create new job object.
   *
   * @param newState New state of job.
   * @param until Do not execute job until after `until`.
   * @param description Free form description
   * @return New job object
   */
  public Job newState(
      final Enum<? extends State> newState,
      final Instant until,
      final String description
  ) {
    final int nextRecord = this.getState().equals(newState.name())
        ? this.jobKey.getRecord()
        : this.jobKey.getRecord() + 1;
    return new Job(
        new JobKey(this.jobKey.getJobId(), nextRecord),
        this.jobType,
        this.parentJobId,
        newState.name(),
        Instant.now(),
        until,
        description);
  }
}
