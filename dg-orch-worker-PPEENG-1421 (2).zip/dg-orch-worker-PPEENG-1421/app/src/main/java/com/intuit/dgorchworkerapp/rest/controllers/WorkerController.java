package com.intuit.dgorchworkerapp.rest.controllers;

import static net.logstash.logback.argument.StructuredArguments.v;

import com.intuit.dgorchworkerapp.data.JobDao;
import com.intuit.dgorchworkerapp.data.models.PersonaType;
import com.intuit.dgorchworkerapp.data.models.WorkerAccessContext;
import com.intuit.dgorchworkerapp.rest.controllers.exceptions.WorkerAccessConstraintViolationException;
import com.intuit.dgorchworkerapp.rest.controllers.model.JobDetailResponse;
import com.intuit.dgorchworkerapp.rest.controllers.model.JobResponse;
import com.intuit.dgorchworkerapp.rest.controllers.model.WorkerAccessRequest;
import com.intuit.dgorchworkerapp.statemachine.JobType;
import com.intuit.dgorchworkerapp.statemachine.StateAttributes;
import com.intuit.dgorchworkerapp.statemachine.StateMachineController;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.WorkerAccessState;
import com.intuit.platform.jsk.security.iam.authn.IntuitTicketAuthentication;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller to manage worker jobs.
 */
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping(value = "v1/worker", produces = {MediaType.APPLICATION_JSON_VALUE})
@Tag(name = "worker")
public class WorkerController {

  private final StateMachineController stateMachineController;
  private final JobDao jobDao;

  /**
   * Create new job to process.
   */
  @RequestMapping(method = RequestMethod.POST, path = "access")
  @Operation(
      description = "Submit worker access job for processing",
      summary = "Submit worker access job",
      security = {@SecurityRequirement(name = "privateAuthUser", scopes = {})}
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Request submitted"),
      @ApiResponse(responseCode = "400", description = "Bad request")
  })
  public JobResponse submitWorkOrder(
      @RequestBody final WorkerAccessRequest workerAccessRequest,
      @Parameter(hidden = true) final IntuitTicketAuthentication principal
  ) {
    log.info("Got request for {}", v("principal", principal != null ? principal.getName() : null));
    final PersonaType personaType;
    try {
      personaType = PersonaType.valueOf(workerAccessRequest.getPersonaType());
    } catch (final IllegalArgumentException e) {
      throw new WorkerAccessConstraintViolationException(
          "Unknown persona type: " + workerAccessRequest.getPersonaType(), e);
    }
    final WorkerAccessContext workerAccessContext = WorkerAccessContext.builder()
        .authId(workerAccessRequest.getAuthId())
        .verifiedIdentities(workerAccessRequest.getVerifiedIdentities())
        .personaType(personaType)
        .personaIdentifier(workerAccessRequest.getPersonaIdentifier())
        .requestedPersonas(workerAccessRequest.getRequestedPersonas())
        .restrictedAssetsOnly(workerAccessRequest.isRestrictedAssetsOnly())
        .restrictedAssetIds(workerAccessRequest.getRestrictedAssetIds())
        .build();

    return JobResponse.fromJob(
        stateMachineController.submit(JobType.WORKER_ACCESS, workerAccessContext, null));
  }

  @RequestMapping(method = RequestMethod.GET, path = "access/{jobId}")
  @Operation(
      description = "Get job by id",
      summary = "Get job",
      security = {@SecurityRequirement(name = "privateAuthUser", scopes = {})}
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Job found"),
      @ApiResponse(responseCode = "400", description = "Bad request")
  })
  public JobDetailResponse<?> getWorkOrder(
      @Parameter(required = true) @PathVariable final String jobId,
      @Parameter(hidden = true) final IntuitTicketAuthentication principal
  ) {
    return stateMachineController.getDetail(jobId);
  }

  /**
   * Get active work orders current state.
   *
   * @param principal Intuit principal
   * @return List of jobs which are runnable
   */
  @RequestMapping(method = RequestMethod.GET, path = "access")
  @Operation(
      description = "Get all active jobs",
      summary = "Get work order",
      security = {@SecurityRequirement(name = "privateAuthUser", scopes = {})}
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "400", description = "Bad request")
  })
  public List<JobResponse> getActiveWorkOrders(
      @Parameter(example = "2022-01-01T00:00:00Z") @RequestParam(required = false)
      final Instant since,
      @Parameter @RequestParam(required = false) final boolean showInactive,
      @Parameter(hidden = true) final IntuitTicketAuthentication principal
  ) {
    final Set<String> statesToFetch = Arrays.stream(WorkerAccessState.values())
        .filter(state -> showInactive || state.getAttributes().contains(StateAttributes.ACTIVE))
        .map(Enum::name)
        .collect(Collectors.toSet());

    return (since != null
        ? jobDao.getJobsSince(JobType.WORKER_ACCESS, statesToFetch, since)
        : jobDao.getJobs(JobType.WORKER_ACCESS, statesToFetch))
        .stream()
        .map(JobResponse::fromJob)
        .collect(Collectors.toList());
  }

  @RequestMapping(method = RequestMethod.POST, path = "access/{jobId}/execute")
  @Operation(
      description = "Cause job to run for job id",
      summary = "Execute job",
      security = {@SecurityRequirement(name = "privateAuthUser", scopes = {})}
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "400", description = "Bad request")
  })
  public JobResponse executeWorkOrder(
      @Parameter(required = true) @PathVariable final String jobId,
      @Parameter(hidden = true) final IntuitTicketAuthentication principal
  ) {
    return JobResponse.fromJob(stateMachineController.execute(jobId));
  }

  @RequestMapping(method = RequestMethod.DELETE, path = "access/{jobId}")
  @Operation(
      description = "Cancel job by id",
      summary = "Cancel job",
      security = {@SecurityRequirement(name = "privateAuthUser", scopes = {})}
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "400", description = "Bad request")
  })
  public JobResponse cancelWorkOrder(
      @Parameter(required = true) @PathVariable final String jobId,
      @RequestBody final String reason,
      @Parameter(hidden = true) final IntuitTicketAuthentication principal
  ) {
    return JobResponse.fromJob(stateMachineController.cancel(jobId, reason));
  }
}
