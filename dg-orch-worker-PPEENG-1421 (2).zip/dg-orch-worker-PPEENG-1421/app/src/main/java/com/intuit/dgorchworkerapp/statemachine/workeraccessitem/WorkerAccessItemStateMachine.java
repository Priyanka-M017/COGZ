package com.intuit.dgorchworkerapp.statemachine.workeraccessitem;

import static net.logstash.logback.argument.StructuredArguments.v;

import com.intuit.dgorchworkerapp.data.WorkerAccessItemContextDao;
import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.WorkerAccessItemContext;
import com.intuit.dgorchworkerapp.statemachine.JobType;
import com.intuit.dgorchworkerapp.statemachine.StateMachine;
import com.intuit.dgorchworkerapp.statemachine.workeraccessitem.actions.WorkerAccessItemAction;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * State machine for worker access items.
 */
@Slf4j
@Component
public class WorkerAccessItemStateMachine extends
    StateMachine<WorkerAccessItemContext, WorkerAccessItemState> {

  /**
   * Constructor.
   *
   * @param workerAccessItemContextDao Context dao
   * @param actions State actions
   */
  public WorkerAccessItemStateMachine(
      final WorkerAccessItemContextDao workerAccessItemContextDao,
      final List<WorkerAccessItemAction> actions
  ) {
    super(
        workerAccessItemContextDao,
        actions,
        WorkerAccessItemState.class,
        JobType.WORKER_ACCESS_ITEM);
  }

  @Override
  protected Job nextState(
      final Job job, final WorkerAccessItemContext context
  ) {
    final Job nextState;
    switch (WorkerAccessItemState.valueOf(job.getState())) {
      case PENDING:
        nextState = job.newState(WorkerAccessItemState.PROCESSED);
        break;
      default:
        throw new RuntimeException("Unknown state");
    }
    return nextState;
  }

  @Override
  protected Job onException(
      final Job job, final WorkerAccessItemContext context, final Exception e
  ) {
    log.error("Got exception for job {}", v("job", job), e);
    return job;
  }

  @Override
  protected Job cancel(
      final Job job,
      final WorkerAccessItemContext context,
      final String description
  ) {
    throw new UnsupportedOperationException("Cancel not yet implemented");
  }
}
