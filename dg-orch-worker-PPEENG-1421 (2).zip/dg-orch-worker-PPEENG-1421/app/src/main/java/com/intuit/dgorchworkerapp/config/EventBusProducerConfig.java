package com.intuit.dgorchworkerapp.config;

import com.intuit.dgworker.entity.DgWorkerEvent;
import com.intuit.eventbus.Configuration;
import com.intuit.eventbus.SerializingMessageFormater;
import com.intuit.eventbus.configurations.TypesafeFormatV3;
import com.intuit.eventbus.kafka.serde.Serializer;
import com.intuit.eventbus.message.MetadataV3;
import com.intuit.eventbus.utils.ConfigToProperties;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;
import lombok.Data;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

/**
 * Event bus configurations.
 */
@org.springframework.context.annotation.Configuration
@ConfigurationProperties(prefix = EventBusProducerConfig.PREFIX)
@Data
public class EventBusProducerConfig {

  static final String PREFIX = "eventbus.conf";

  private String file;

  /**
   * Create Kafka producer factory.
   *
   * @return Kafka producer factory
   */
  @Bean
  public ProducerFactory<String, DgWorkerEvent> producerFactory() {
    final Config config = ConfigFactory.parseResources(file);
    final Configuration<SerializingMessageFormater<DgWorkerEvent, MetadataV3>> formatterConf =
        TypesafeFormatV3.serializingFormatter(config.getConfig("formatter"));
    final Serializer<DgWorkerEvent> messageSerializer =
        new Serializer<>(formatterConf.instantiate());

    final Properties kafkaProps = ConfigToProperties.makeProps(config.getConfig("kafka"));

    return new DefaultKafkaProducerFactory<>(
        kafkaProps.entrySet().stream()
            .collect(Collectors.toMap(e -> String.valueOf(e.getKey()), Map.Entry::getValue)),
        new StringSerializer(),
        messageSerializer);
  }

  /**
   * Get Kafka template with default topic set to eventbus topic.
   *
   * @param producerFactory Kafka producer factory
   * @return Kafka template used to send messages
   */
  @Bean
  public KafkaTemplate<String, DgWorkerEvent> kafkaTemplate(
      final ProducerFactory<String, DgWorkerEvent> producerFactory
  ) {
    final Config config = ConfigFactory.parseResources(file);

    final KafkaTemplate<String, DgWorkerEvent> kafkaTemplate =
        new KafkaTemplate<>(producerFactory);
    kafkaTemplate.setDefaultTopic(config.getString("topic"));
    return kafkaTemplate;
  }
}
