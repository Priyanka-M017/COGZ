package com.intuit.dgorchworkerapp.config;

import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.trace.Tracer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Open telemetry beans.
 */
@Configuration
public class OpenTelemetryConfig {
  @Bean
  public Tracer telemetryTracer() {
    return GlobalOpenTelemetry.getTracerProvider().tracerBuilder("dg-orch-worker").build();
  }
}
