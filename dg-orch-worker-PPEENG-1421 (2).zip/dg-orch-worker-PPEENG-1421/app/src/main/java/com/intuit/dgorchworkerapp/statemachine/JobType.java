package com.intuit.dgorchworkerapp.statemachine;

import com.intuit.dgorchworkerapp.statemachine.workeraccess.WorkerAccessStateMachine;
import com.intuit.dgorchworkerapp.statemachine.workeraccessitem.WorkerAccessItemStateMachine;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Possible job types.
 */
@RequiredArgsConstructor
@Getter
public enum JobType {
  WORKER_ACCESS(WorkerAccessStateMachine.class),
  WORKER_ACCESS_ITEM(WorkerAccessItemStateMachine.class);

  public final Class<? extends StateMachine<?, ?>> stateMachineClass;

  /**
   * Get job type for state machine class.
   *
   * @param stateMachineClass State machine to find job type for
   * @return State corresponding for action
   */
  public static Optional<JobType> getJobTypeForMachine(
      @SuppressWarnings("rawtypes") final Class<? extends StateMachine> stateMachineClass
  ) {
    final List<JobType> foundStates =
        Arrays.stream(JobType.values())
            .filter(jobType -> jobType.stateMachineClass != null)
            .filter(jobType -> jobType.stateMachineClass.isAssignableFrom(stateMachineClass))
            .collect(Collectors.toList());

    if (foundStates.size() > 1) {
      throw new RuntimeException("Found more than one state machine for job type");
    } else {
      return foundStates.stream().findFirst();
    }
  }
}
