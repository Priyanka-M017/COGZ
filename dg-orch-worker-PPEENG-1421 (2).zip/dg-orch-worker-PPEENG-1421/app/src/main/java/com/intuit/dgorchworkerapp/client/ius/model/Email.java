package com.intuit.dgorchworkerapp.client.ius.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;

/** possible User attributes for profile creation. */
@Data
@Builder
@Jacksonized
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Email {
  private final String id;
  private final String type;
  private final String usageType;
  private final Boolean primary;
  private final String address;
  private final String status;
}
