package com.intuit.dgorchworkerapp.data.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity to capture the details of the worker entity types that are housed in your data store.
 */
@Entity
@Table
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ManagedType {

  @Id
  @Column
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @JsonIgnore private long managedTypeId;

  @Column @JsonIgnore private long assetId;

  @Column private String managedTypeValue;

  @Column @JsonIgnore private Timestamp createdDate;

  @Column @JsonIgnore private Timestamp deletedDate;

}
