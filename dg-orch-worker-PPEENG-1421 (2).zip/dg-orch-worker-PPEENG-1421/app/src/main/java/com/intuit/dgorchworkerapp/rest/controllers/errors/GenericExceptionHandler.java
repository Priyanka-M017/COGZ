package com.intuit.dgorchworkerapp.rest.controllers.errors;

import com.intuit.dgorchworkerapp.rest.controllers.exceptions.WorkerAccessConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Generic handler to produce the correct response for exceptions.
 */
@ResponseBody
@ControllerAdvice
public class GenericExceptionHandler {
  private static final Logger LOGGER = LoggerFactory.getLogger(GenericExceptionHandler.class);

  @Value("${server.include-debug-info}")
  private boolean includeDebugInfo;

  /**
   * Handle empty request exceptions.
   */
  @ExceptionHandler
  public SimpleErrorResponse handleDocumentException(
      final HttpMessageNotReadableException e
  ) {
    return genericErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage(), e);
  }

  /**
   * Handle request exceptions.
   */
  @ExceptionHandler
  public SimpleErrorResponse handleDocumentException(
      final WorkerAccessConstraintViolationException e
  ) {
    return genericErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage(), e);
  }

  /**
   * Handle Other Errors.
   *
   * @param t Exception to handle
   * @return HTTP error response
   */
  @ExceptionHandler
  public SimpleErrorResponse handleOtherErrors(final Throwable t) {
    LOGGER.error("handling an unexpected exception", t);
    return genericErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR,
        "An unexpected error occurred processing this request", t);
  }

  private SimpleErrorResponse genericErrorResponse(
      final HttpStatus status,
      final String message,
      final Throwable e
  ) {
    return new SimpleErrorResponse(status, message, e, includeDebugInfo);
  }
}
