package com.intuit.dgorchworkerapp.service;

import com.intuit.dgorchworkerapp.data.models.DataManagerConfig;
import com.intuit.dgorchworkerapp.repository.DataManagerRepository;
import com.intuit.dgorchworkerapp.rest.controllers.model.DataManagerConfigDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/** Data Manager Service layer. */
@Slf4j
@RequiredArgsConstructor
@Component
@Service
public class DataManagerService {

  private final DataManagerRepository dataManagerRepository;

  /**
   * Method to get the data manager on-boarding details for employee / worker.
   *
   * @param assetId asset id
   * @return data manger details for that particular asset
   */
  public DataManagerConfigDto getAssetById(final int assetId) {
    return dataManagerRepository.findById((long) assetId).map(this::convertEntityToDto).get();
  }

  /**
   * Method to save the data manager on-boarding details for employee / worker.
   *
   * @param dataManagerConfig dataManagerConfig
   * @return data manger details for that particular asset
   */
  public DataManagerConfigDto saveOrUpdate(final DataManagerConfig dataManagerConfig) {
    dataManagerRepository.save(dataManagerConfig);
    return convertEntityToDto(dataManagerConfig);
  }

  /**
   * Method to check if the asset id is available in the database.
   *
   * @param assetId assetId
   * @return data manger details for that particular asset
   */
  public boolean existsById(final int assetId) {
    return dataManagerRepository.existsById((long) assetId);
  }

  /**
   * Method to convert/map the database object to the API object.
   *
   * @param dataManagerConfig dmConfig database object
   * @return dmConfigDTO api object
   */
  public DataManagerConfigDto convertEntityToDto(final DataManagerConfig dataManagerConfig) {
    final DataManagerConfigDto dataManagerConfigDto = DataManagerConfigDto.builder()
            .assetId(dataManagerConfig.getAssetId())
            .managedTypeList(dataManagerConfig.getManagedTypeDetails())
            .onboardStage(dataManagerConfig.getOnboardStage())
            .createdDate(dataManagerConfig.getCreatedDate())
            .deletedDate(dataManagerConfig.getDeletedDate())
            .dataStoreDetails(dataManagerConfig.getDataStoreDetails())
            .dataEntityDetails(dataManagerConfig.getDataEntityDetails())
            .extEngagementDetails(dataManagerConfig.getExtEngagementDetails())
            .build();
    return dataManagerConfigDto;
  }
}
