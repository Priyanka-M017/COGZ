package com.intuit.dgorchworkerapp.client.ius;

import static com.intuit.dgorchworkerapp.client.auth.SystemOfflineTicketAuthorizedClientExchangeFilterFunction.AUTH_ID_ATTRIBUTE;

import com.intuit.cto.general.io.utils.http.IntuitCommonHeaders;
import com.intuit.dgorchworkerapp.client.auth.SystemOfflineTicketAuthorizedClientExchangeFilterFunction;
import com.intuit.dgorchworkerapp.client.ius.model.User;
import com.intuit.platform.integration.hats.common.AccessDeniedException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * Client for IUS service.
 */
@Slf4j
@Component
public class IusServiceClient {

  private static final String USERS_PATH = "/v1/users/{authId}";

  private final WebClient webClient;

  /**
   * Constructor.
   *
   * @param properties Client configuration
   * @param webClient WebClient to use for rest call
   */
  public IusServiceClient(
      final IusServiceProperties properties,
      final WebClient webClient,
      final SystemOfflineTicketAuthorizedClientExchangeFilterFunction authFilterFunction
  ) {
    this.webClient = webClient.mutate()
        .baseUrl(properties.getBaseUrl())
        .filter(authFilterFunction)
        .build();
  }

  /**
   * This method calls IUS api to retrieve User Profile for given authId.
   *
   * @param authId worker authid
   * @param tid transaction id of request
   * @return user response
   */
  public User getUser(final String authId, final String tid) throws AccessDeniedException {
    try {
      return webClient.get()
          .uri(uriBuilder -> uriBuilder.path(USERS_PATH).build(authId))
          .attribute(AUTH_ID_ATTRIBUTE, authId)
          .accept(MediaType.APPLICATION_JSON)
          .header(IntuitCommonHeaders.INTUIT_HEADER_TID, tid)
          .retrieve()
          .bodyToMono(User.class)
          .block();
    } catch (final RuntimeException e) {
      final Throwable cause = e.getCause();
      if (cause instanceof AccessDeniedException) {
        throw (AccessDeniedException) cause;
      } else {
        throw e;
      }
    }
  }
}
