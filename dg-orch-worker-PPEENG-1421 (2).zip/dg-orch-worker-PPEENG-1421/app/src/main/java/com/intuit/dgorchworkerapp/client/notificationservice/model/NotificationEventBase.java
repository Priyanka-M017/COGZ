package com.intuit.dgorchworkerapp.client.notificationservice.model;

import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;

/**
 * Notification event request object.
 */
@Builder
@Data
@Jacksonized
public class NotificationEventBase<T extends EventData> {
  private final String name;
  private final String sourceServiceName;
  private final String sourceObjectId;
  private final String sourceObjectType;
  private final T eventData;
  private final NotificationEventMetadata eventMetaData;
}
