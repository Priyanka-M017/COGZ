package com.intuit.dgorchworkerapp.statemachine;

import com.intuit.dgorchworkerapp.data.JobContextDao;
import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.JobContext;
import com.intuit.dgorchworkerapp.data.models.JobKey;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.transaction.Transactional;

/**
 * State machine for orchestrating work.
 *
 * @param <T> Context type of job
 * @param <V> States
 */
public abstract class StateMachine<T extends JobContext, V extends Enum<? extends State>> {

  private final JobContextDao<T, String> jobContextDao;
  private final Map<Enum<? extends State>, ? extends Action<T>> actions;
  private final JobType jobType;
  private final V initialState;
  private final Class<V> statesClass;

  /**
   * Constructor.
   *
   * @param jobContextDao Job context dao to get job context
   * @param actions Actions executable by this state machine
   * @param statesClass States handled by this state machine
   * @param jobType Type of job done by this state machine
   */
  @SuppressWarnings("unchecked")
  public StateMachine(
      final JobContextDao<T, String> jobContextDao,
      final List<? extends Action<T>> actions,
      final Class<V> statesClass,
      final JobType jobType
  ) {
    this.jobContextDao = jobContextDao;
    this.jobType = jobType;
    this.statesClass = statesClass;

    final List<V> initialStateList = Arrays.stream(statesClass.getEnumConstants())
        .map(State.class::cast)
        .filter(i -> i.getAttributes().contains(StateAttributes.INITIAL))
        .map(i -> (V) i)
        .collect(Collectors.toList());

    if (initialStateList.size() != 1) {
      throw new RuntimeException("One and only one state must be marked initial");
    }

    this.initialState = initialStateList.get(0);

    this.actions = actions.stream()
        .collect(Collectors.toMap(
            action ->
                State.getStateForAction(statesClass, action.getClass()).orElseThrow(),
            Function.identity()));
    if (!this.actions.keySet().containsAll(State.getActiveStates(statesClass))) {
      throw new RuntimeException("Not all active states have actions");
    }
  }

  /**
   * Submit work order for job.
   *
   * @param initialContext Work order that job will execute on
   * @return Job's initial state
   */
  @Transactional
  protected Job submit(
      final String jobId,
      final JobContext initialContext,
      final String parentJobId
  ) {
    final Job newJob = new Job(
        new JobKey(jobId, 0),
        jobType,
        parentJobId,
        initialState.name(),
        Instant.now(),
        Instant.now(),
        "");
    jobContextDao.save(initialContext.withId(jobId));
    return newJob;
  }

  protected abstract Job nextState(final Job job, final T context);

  protected abstract Job onException(final Job job, final T context, final Exception e);

  /**
   * Execute on job.
   *
   * @param job Job to execute
   * @return New job state
   */
  @Transactional
  protected Job execute(final Job job) {
    final T jobContext = jobContextDao.findById(job.getJobKey().getJobId()).orElse(null);

    try {
      final T newContext =
          actions.get(V.valueOf(statesClass.asSubclass(Enum.class), job.getState()))
              .onExecute(job, jobContext);
      final Job nextState = nextState(job, newContext);

      jobContextDao.save(newContext);
      return nextState;
    } catch (final Exception e) {
      return onException(job, jobContext, e);
    }
  }

  /**
   * Callback to job.
   *
   * @param job Job to callback
   * @param body Body of callback
   * @return New job state
   */
  @Transactional
  protected Job callback(final Job job, final String body) {
    final T jobContext = jobContextDao.findById(job.getJobKey().getJobId()).orElse(null);

    try {
      final T newContext =
          actions.get(V.valueOf(statesClass.asSubclass(Enum.class), job.getState()))
              .onCallback(job, jobContext, body);
      final Job nextState = nextState(job, newContext);

      jobContextDao.save(newContext);
      return nextState.equals(job) ? job : nextState;
    } catch (final Exception e) {
      return onException(job, jobContext, e);
    }
  }

  protected abstract Job cancel(final Job job, final T context, final String description);

  /**
   * Cancel job.
   *
   * @param job Job to cancel
   * @param description Cancellation description
   * @return Job object showing cancellation
   */
  @Transactional
  protected Job cancel(final Job job, final String description) {
    final T jobContext = jobContextDao.findById(job.getJobKey().getJobId()).orElse(null);

    final boolean canCancel =
        ((State) V.valueOf(statesClass.asSubclass(Enum.class), job.getState()))
            .getAttributes()
            .contains(StateAttributes.CANCELABLE);
    if (!canCancel) {
      throw new RuntimeException("Cannot cancel job in state " + job.getState());
    }

    return cancel(job, jobContext, description);
  }

  /**
   * Get details for job.
   *
   * @param job Job to get details for
   * @return Job's context and state history
   */
  @Transactional
  protected T getContext(final Job job) {
    return jobContextDao.findById(job.getJobKey().getJobId()).orElse(null);
  }

  /**
   * Get states that define this state machine.
   *
   * @return State machine's states
   */
  protected Class<V> getStates() {
    return statesClass;
  }
}
