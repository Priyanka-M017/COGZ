package com.intuit.dgorchworkerapp.statemachine.workeraccess.actions;

import static net.logstash.logback.argument.StructuredArguments.v;

import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.WorkerAccessContext;
import com.intuit.dgorchworkerapp.statemachine.State;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.WorkerAccessState;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Action class for worker access legal holds check in progress state.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class LegalHoldsCheckInProgressAction implements WorkerAccessAction {

  @Override
  public WorkerAccessContext onExecute(
      final Job job,
      final WorkerAccessContext context
  ) {
    log.info("Run {} for {}",
        v("state", State.getStateForAction(WorkerAccessState.class, this.getClass())),
        v("context", context));
    return context;
  }
}
