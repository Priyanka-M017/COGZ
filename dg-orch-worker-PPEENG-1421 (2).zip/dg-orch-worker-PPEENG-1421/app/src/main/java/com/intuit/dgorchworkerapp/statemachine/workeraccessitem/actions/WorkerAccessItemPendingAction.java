package com.intuit.dgorchworkerapp.statemachine.workeraccessitem.actions;

import static net.logstash.logback.argument.StructuredArguments.v;

import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.WorkerAccessItemContext;
import com.intuit.dgorchworkerapp.statemachine.State;
import com.intuit.dgorchworkerapp.statemachine.workeraccessitem.WorkerAccessItemState;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Action class for worker access item pending state.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class WorkerAccessItemPendingAction implements WorkerAccessItemAction {

  @Override
  public WorkerAccessItemContext onCallback(
      final Job job,
      final WorkerAccessItemContext context,
      final String body
  ) {
    log.info("Callback on {} for {} with body {}",
        v("state", State.getStateForAction(WorkerAccessItemState.class, this.getClass())),
        v("context", context),
        v("body", body));
    return context;
  }
}
