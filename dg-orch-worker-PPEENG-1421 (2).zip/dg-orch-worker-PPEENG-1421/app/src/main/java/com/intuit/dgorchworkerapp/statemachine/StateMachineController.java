package com.intuit.dgorchworkerapp.statemachine;

import static net.logstash.logback.argument.StructuredArguments.v;

import com.intuit.dgorchworkerapp.data.JobDao;
import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.JobContext;
import com.intuit.dgorchworkerapp.rest.controllers.model.JobDetailResponse;
import com.intuit.dgorchworkerapp.rest.controllers.model.JobResponse;
import com.intuit.instrumentation.library.micrometer.aspect.Instrument;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * Controller for the management of state machines.
 */
@Slf4j
@Component
public class StateMachineController {

  private final JobDao jobDao;
  private Map<JobType, ? extends StateMachine<?, ?>> stateMachineMap;

  /**
   * State machine controller constructor.
   *
   * @param jobDao DAO to get job data
   * @param stateMachines List of state machines to control
   */
  public StateMachineController(final JobDao jobDao, final List<StateMachine<?, ?>> stateMachines) {
    this.jobDao = jobDao;
    setStateMachines(stateMachines);
  }

  /**
   * State machine controller constructor used for spring injection.
   *
   * @param jobDao DAO to get job data
   */
  @Autowired
  public StateMachineController(final JobDao jobDao) {
    this.jobDao = jobDao;
  }

  /**
   * Set state machines via setter used for spring injection.
   *
   * @param stateMachines State machines to
   */
  @Autowired
  @Lazy
  public void setStateMachines(final List<StateMachine<?, ?>> stateMachines) {
    stateMachineMap = stateMachines.stream().collect(Collectors.toMap(
        stateMachine -> JobType.getJobTypeForMachine(stateMachine.getClass()).orElseThrow(),
        Function.identity()));
  }

  /**
   * Submit work order for job.
   *
   * @param initialContext Work order that job will execute on
   * @return Job's initial state
   */
  @Transactional
  @Instrument
  public Job submit(
      final JobType jobType,
      final JobContext initialContext,
      final String parentJobId
  ) {
    final String jobId = UUID.randomUUID().toString();
    try (MDC.MDCCloseable closeableJobIdMdc = MDC.putCloseable("jobId", jobId)) {
      final Job newJob = stateMachineMap.get(jobType).submit(jobId, initialContext, parentJobId);
      return jobDao.save(newJob);
    }
  }

  /**
   * Execute on job.
   *
   * @param jobId Job to execute
   * @return New job state
   */
  @Transactional
  @Instrument
  public Job execute(final String jobId) {
    try (MDC.MDCCloseable closeableMdc = MDC.putCloseable("jobId", jobId)) {
      final Job job = jobDao.getCurrentState(jobId);
      try (MDC.MDCCloseable stateMdc = MDC.putCloseable("currentState", job.getState())) {
        final Job nextState = stateMachineMap.get(job.getJobType()).execute(job);
        log.info("Transitioning to new state {}", v("newState", nextState.getState()));
        return nextState.equals(job) ? job : jobDao.save(nextState);
      }
    }
  }

  /**
   * Callback to job.
   *
   * @param jobId Job to callback
   * @param body Body of callback
   * @return New job state
   */
  @Transactional
  @Instrument
  public Job callback(final String jobId, final String body) {
    try (MDC.MDCCloseable closeableMdc = MDC.putCloseable("jobId", jobId)) {
      final Job job = jobDao.getCurrentState(jobId);
      try (MDC.MDCCloseable stateMdc = MDC.putCloseable("currentState", job.getState())) {
        final Job nextState = stateMachineMap.get(job.getJobType()).callback(job, body);
        log.info("Transitioning to new state {}", v("newState", nextState.getState()));
        return nextState.equals(job) ? job : jobDao.save(nextState);
      }
    }
  }

  /**
   * Cancel job.
   *
   * @param jobId Job id to cancel
   * @param description Cancellation description
   * @return Job object showing cancellation
   */
  @Transactional
  @Instrument
  public Job cancel(final String jobId, final String description) {
    try (MDC.MDCCloseable closeableMdc = MDC.putCloseable("jobId", jobId)) {
      final Job job = jobDao.getCurrentState(jobId);
      try (MDC.MDCCloseable stateMdc = MDC.putCloseable("currentState", job.getState())) {
        final Job nextState = stateMachineMap.get(job.getJobType()).cancel(job, description);
        log.info("Transitioning to new state {}", v("newState", nextState.getState()));
        return nextState.equals(job) ? job : jobDao.save(nextState);
      }
    }
  }

  /**
   * Get details for job.
   *
   * @param jobId Job id to get details for
   * @return Job's context and state history
   */
  @Transactional
  @Instrument
  public JobDetailResponse<? extends JobContext> getDetail(final String jobId) {
    try (MDC.MDCCloseable closeableMdc = MDC.putCloseable("jobId", jobId)) {
      final List<Job> allStatesForJob = jobDao.getAllStates(jobId);
      final JobContext jobContext = allStatesForJob.stream()
          .findFirst()
          .map(job -> stateMachineMap.get(job.getJobType()).getContext(job))
          .orElse(null);

      return JobDetailResponse.<JobContext>builder()
          .jobStates(
              allStatesForJob.stream().map(JobResponse::fromJob).collect(Collectors.toList()))
          .jobContext(jobContext)
          .build();
    }
  }
}
