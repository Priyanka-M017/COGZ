package com.intuit.dgorchworkerapp.config;

import com.intuit.dgorchworkerapp.client.auth.IntuitOfflineTicketProperties;
import com.intuit.platform.integration.iam.client.IAMServiceConfiguration;
import com.intuit.platform.integration.iam.client.auth.BasicIAMServiceCredentials;
import com.intuit.platform.integration.iam.client.auth.IAMServiceCredentialsProvider;
import com.intuit.platform.integration.iam.client.auth.StaticIAMServiceCredentialsProvider;
import com.intuit.platform.integration.iamticket.client.IAMOfflineTicketClient;
import com.intuit.platform.integration.iamticket.client.IAMOfflineTicketServiceConfiguration;
import com.intuit.platform.jsk.security.iam.autoconfig.IntuitSecurityProperties;
import io.netty.channel.ChannelOption;
import java.time.Duration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

/**
 * Configurations for WebClient used to call rest downstream services.
 */
@Configuration
@EnableConfigurationProperties({
    IntuitSecurityProperties.class,
    IntuitOfflineTicketProperties.class
})
public class WebClientConfig {

  private final Duration defaultConnectTimeout = Duration.ofSeconds(30);
  private final Duration defaultReadTimeout = Duration.ofSeconds(30);

  /**
   * Configured reactive http client to be used by WebClient.
   *
   * @return Configured reactive http client
   */
  @Bean
  public HttpClient httpClient() {
    return HttpClient.create()
        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, defaultConnectTimeout.toMillisPart())
        .responseTimeout(defaultReadTimeout);
  }

  /**
   * Get a base WebClient with basic functionality.
   *
   * @param httpClient Configured http client
   * @return WebClient to be mutated by service classes
   */
  @Bean
  public WebClient webClient(final HttpClient httpClient) {
    return WebClient.builder()
        .clientConnector(new ReactorClientHttpConnector(httpClient))
        .build();
  }

  /**
   * Client for acquiring offline tickets.
   *
   * @param intuitSecurityProperties Security Properties file
   * @return Client used to acquire offline tickets
   */
  @Bean
  public IAMOfflineTicketClient iamOfflineTicketClient(
      final IntuitSecurityProperties intuitSecurityProperties,
      final IntuitOfflineTicketProperties intuitOfflineTicketProperties
  ) {
    final IAMServiceCredentialsProvider serviceCredentialsProvider =
        new StaticIAMServiceCredentialsProvider(
            new BasicIAMServiceCredentials(intuitSecurityProperties.getAppId(),
                intuitSecurityProperties.getAppSecret()));

    final IAMServiceConfiguration serviceConfig =
        new IAMOfflineTicketServiceConfiguration(
            intuitOfflineTicketProperties.getOfflineTicketUrl(),
            serviceCredentialsProvider
        );

    return new IAMOfflineTicketClient(serviceConfig);
  }
}
