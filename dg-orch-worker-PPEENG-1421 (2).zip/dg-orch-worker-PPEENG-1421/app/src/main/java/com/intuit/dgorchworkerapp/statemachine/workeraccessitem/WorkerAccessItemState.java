package com.intuit.dgorchworkerapp.statemachine.workeraccessitem;

import com.intuit.dgorchworkerapp.statemachine.State;
import com.intuit.dgorchworkerapp.statemachine.StateAttributes;
import com.intuit.dgorchworkerapp.statemachine.workeraccessitem.actions.WorkerAccessItemAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccessitem.actions.WorkerAccessItemPendingAction;
import java.util.Arrays;
import java.util.EnumSet;
import lombok.Getter;

/**
 * Possible job states.
 */
@Getter
public enum WorkerAccessItemState implements State {
  PENDING(
      WorkerAccessItemPendingAction.class,
      StateAttributes.INITIAL,
      StateAttributes.ACTIVE),
  PROCESSED(
      null,
      StateAttributes.TERMINAL_SUCCESS);

  private final Class<? extends WorkerAccessItemAction> actionClass;
  private final EnumSet<StateAttributes> attributes;

  WorkerAccessItemState(
      final Class<? extends WorkerAccessItemAction> actionClass,
      final StateAttributes... attributes
  ) {
    this.actionClass = actionClass;
    this.attributes = attributes.length > 0
        ? EnumSet.copyOf(Arrays.asList(attributes))
        : EnumSet.noneOf(StateAttributes.class);
  }
}
