package com.intuit.dgorchworkerapp.rest.controllers.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.intuit.dgorchworkerapp.data.models.Job;
import java.time.Instant;
import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;

/**
 * API response for job objects.
 */
@Builder
@Data
@Jacksonized
@JsonInclude(JsonInclude.Include.NON_NULL)
public class JobResponse {
  private final String jobId;
  private final int record;
  private final String jobType;
  private final String parentJobId;
  private final String state;
  private final Instant since;
  private final Instant until;
  private final String description;

  /**
   * Build job response from Job DAO object.
   */
  public static JobResponse fromJob(final Job job) {
    return JobResponse.builder()
        .jobId(job.getJobKey().getJobId())
        .record(job.getJobKey().getRecord())
        .jobType(job.getJobType().toString())
        .parentJobId(job.getParentJobId() != null ? job.getParentJobId() : null)
        .state(job.getState())
        .since(job.getSince())
        .until(job.getUntil())
        .description(job.getDescription() != null && !job.getDescription().isBlank()
            ? job.getDescription()
            : null)
        .build();
  }
}
