package com.intuit.dgorchworkerapp.statemachine;

import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.JobContext;

/**
 * State machine action interface.
 */
public interface Action<T extends JobContext> {

  /**
   * Execute action.
   *
   * @param job Current job
   * @param context Job context
   * @return Updated context
   */
  default T onExecute(final Job job, final T context) throws Exception {
    throw new UnsupportedOperationException();
  }

  /**
   * Respond to callback.
   *
   * @param job Current job
   * @param context Job context
   * @param body Body data
   * @return Updated context
   */
  default T onCallback(final Job job, final T context, final String body) throws Exception {
    throw new UnsupportedOperationException();
  }
}
