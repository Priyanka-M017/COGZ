package com.intuit.dgorchworkerapp.statemachine;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Interface representing state enums.
 */
public interface State {
  Class<? extends Action<?>> getActionClass();

  EnumSet<StateAttributes> getAttributes();

  /**
   * Get state for action class.
   *
   * @param stateEnum State enum to search for state
   * @param actionClass Action to find state for
   * @return State corresponding for action
   */
  @SuppressWarnings("unchecked")
  static <T extends Enum<? extends State>> Optional<T> getStateForAction(
      final Class<T> stateEnum,
      @SuppressWarnings("rawtypes") final Class<? extends Action> actionClass
  ) {
    final List<State> foundStates =
        Arrays.stream(stateEnum.getEnumConstants())
            .map(State.class::cast)
            .filter(state -> state.getActionClass() != null)
            .filter(state -> state.getActionClass().isAssignableFrom(actionClass))
            .collect(Collectors.toList());

    if (foundStates.size() > 1) {
      throw new RuntimeException("Found more than one state for action");
    } else {
      return foundStates.stream().map(state -> (T) state).findFirst();
    }
  }

  /**
   * Get states that are runnable by the state machine. ie not waiting, completed, or failed.
   *
   * @return Runnable states
   */
  @SuppressWarnings("unchecked")
  static <T extends Enum<? extends State>> Set<T> getRunnableStates(final Class<T> stateEnum) {
    return Arrays.stream(stateEnum.getEnumConstants())
        .map(State.class::cast)
        .filter(state -> state.getAttributes().contains(StateAttributes.RUNNABLE))
        .map(state -> (T) state)
        .collect(Collectors.toSet());
  }

  /**
   * Get states that are active in the state machine. ie not completed or failed.
   *
   * @return Runnable states
   */
  @SuppressWarnings("unchecked")
  static <T extends Enum<? extends State>> Set<T> getActiveStates(final Class<T> stateEnum) {
    return Arrays.stream(stateEnum.getEnumConstants())
        .map(State.class::cast)
        .filter(state -> state.getAttributes().contains(StateAttributes.ACTIVE))
        .map(state -> (T) state)
        .collect(Collectors.toSet());
  }
}
