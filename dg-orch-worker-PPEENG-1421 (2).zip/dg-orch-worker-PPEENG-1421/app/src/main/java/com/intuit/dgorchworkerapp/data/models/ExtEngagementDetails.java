package com.intuit.dgorchworkerapp.data.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity to capture the details of the third party vendor engagement(s) that will be handled.
 */
@Entity
@Table
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExtEngagementDetails {

  @Id
  @Column
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long extEngagementId;

  @Column @JsonIgnore private long assetId;

  @Column private String extEngagementValue;

  @Column @JsonIgnore private Timestamp createdDate;

  @Column @JsonIgnore private Timestamp deletedDate;
}
