package com.intuit.dgorchworkerapp.client.auth;

import com.intuit.platform.integration.hats.common.InvalidRequestException;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

/**
 * Filter function to apply offline ticket to request.
 */
@Slf4j
@Component
public class SystemOfflineTicketAuthorizedClientExchangeFilterFunction
    implements ExchangeFilterFunction {

  public static final String AUTH_ID_ATTRIBUTE = "authId";
  public static final String CONSENT_PURPOSE_ATTRIBUTE = "consentPurpose";

  private static final String DEFAULT_PURPOSE = "Intuit.datagovern.compliance.dgworkerofflinejob";

  private final OfflineTicketProvider offlineTicketProvider;

  @Autowired
  public SystemOfflineTicketAuthorizedClientExchangeFilterFunction(
      final OfflineTicketProvider offlineTicketProvider
  ) {
    this.offlineTicketProvider = offlineTicketProvider;
  }

  @NotNull
  @Override
  public Mono<ClientResponse> filter(
      @NotNull final ClientRequest request,
      @NotNull final ExchangeFunction next
  ) {
    final Optional<String> authIdFromAttribute =
        request.attribute(AUTH_ID_ATTRIBUTE).map(String.class::cast);
    final Optional<String> consentPurposeAttribute =
        request.attribute(CONSENT_PURPOSE_ATTRIBUTE).map(String.class::cast);

    final String authHeader;
    try {
      if (authIdFromAttribute.isPresent()) {
        authHeader = this.offlineTicketProvider.getOfflineTicketHeader(
            authIdFromAttribute.get(),
            consentPurposeAttribute.orElse(DEFAULT_PURPOSE)
        );
      } else {
        authHeader = this.offlineTicketProvider.getOfflineTicketHeader();
      }
    } catch (final InvalidRequestException e) {
      return Mono.error(e);
    }

    return next.exchange(ClientRequest.from(request)
        .header(HttpHeaders.AUTHORIZATION, authHeader)
        .build())
        .doOnError(WebClientResponseException.class,
            e -> log.error(String.valueOf(e.getRawStatusCode())));
  }
}
