package com.intuit.dgorchworkerapp.client.icims;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * ICIMS service configuration properties.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Configuration
@ConfigurationProperties(prefix = IcimsServiceProperties.PREFIX)
public class IcimsServiceProperties {
  public static final String PREFIX = "icimsservice";

  private String baseUrl;
  /**
   * This is Intuit's customer id that we get for being ICIMS' customer. This is not a customer of
   * Intuit.
   */
  private String customerId;
}
