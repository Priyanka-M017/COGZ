package com.intuit.dgorchworkerapp.data.models;

/**
 * Possible persona types.
 */
public enum PersonaType {
  EMPLOYEE_ACTIVE,
  EMPLOYEE_TERMINATED,
  CWF_ACTIVE,
  CWF_TERMINATED,
  CANDIDATE
}
