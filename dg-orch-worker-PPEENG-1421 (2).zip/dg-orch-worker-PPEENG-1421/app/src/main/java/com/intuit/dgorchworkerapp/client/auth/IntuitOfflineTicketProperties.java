package com.intuit.dgorchworkerapp.client.auth;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Properties for offline tickets.
 */
@Data
@Configuration
@ConfigurationProperties(prefix = IntuitOfflineTicketProperties.PREFIX)
public class IntuitOfflineTicketProperties {

  public static final String PREFIX = "intuit.offline";

  private String offlineTicketUrl;
  private String sysUserName;
  private String sysPassword;
  private String intuitAssetId;
  private String offlineTicketTtl;
  private String originatingIp;
}
