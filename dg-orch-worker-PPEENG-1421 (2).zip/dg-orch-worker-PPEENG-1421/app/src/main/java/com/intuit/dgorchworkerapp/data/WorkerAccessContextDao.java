package com.intuit.dgorchworkerapp.data;

import com.intuit.dgorchworkerapp.data.models.WorkerAccessContext;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * Data access object for work order table.
 */
@Repository
public interface WorkerAccessContextDao
    extends JobContextDao<WorkerAccessContext, String>,
    JpaRepository<WorkerAccessContext, String>,
    JpaSpecificationExecutor<WorkerAccessContext> {
}
