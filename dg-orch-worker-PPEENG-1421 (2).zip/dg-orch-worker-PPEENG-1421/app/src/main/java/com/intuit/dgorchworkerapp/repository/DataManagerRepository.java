package com.intuit.dgorchworkerapp.repository;

import com.intuit.dgorchworkerapp.data.models.DataManagerConfig;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Data Manager Repository.
 */
public interface DataManagerRepository extends JpaRepository<DataManagerConfig, Long> {

}
