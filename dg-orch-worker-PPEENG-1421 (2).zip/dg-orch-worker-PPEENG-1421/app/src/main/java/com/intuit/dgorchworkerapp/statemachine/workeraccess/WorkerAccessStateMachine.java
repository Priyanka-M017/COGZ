package com.intuit.dgorchworkerapp.statemachine.workeraccess;

import static net.logstash.logback.argument.StructuredArguments.v;

import com.intuit.dgorchworkerapp.data.JobDao;
import com.intuit.dgorchworkerapp.data.WorkerAccessContextDao;
import com.intuit.dgorchworkerapp.data.models.Job;
import com.intuit.dgorchworkerapp.data.models.WorkerAccessContext;
import com.intuit.dgorchworkerapp.statemachine.JobType;
import com.intuit.dgorchworkerapp.statemachine.StateAttributes;
import com.intuit.dgorchworkerapp.statemachine.StateMachine;
import com.intuit.dgorchworkerapp.statemachine.workeraccess.actions.WorkerAccessAction;
import com.intuit.dgorchworkerapp.statemachine.workeraccessitem.WorkerAccessItemState;
import com.intuit.platform.integration.hats.common.AccessDeniedException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * State machine for worker access requests.
 */
@Slf4j
@Component
public class WorkerAccessStateMachine extends StateMachine<WorkerAccessContext, WorkerAccessState> {

  private final JobDao jobDao;

  /**
   * Constructor.
   *
   * @param jobDao Job dao
   * @param workerAccessContextDao Context dao
   * @param actions State actions
   */
  public WorkerAccessStateMachine(
      final JobDao jobDao,
      final WorkerAccessContextDao workerAccessContextDao,
      final List<WorkerAccessAction> actions
  ) {
    super(
        workerAccessContextDao,
        actions,
        WorkerAccessState.class,
        JobType.WORKER_ACCESS);
    this.jobDao = jobDao;
  }

  @Override
  protected Job nextState(final Job job, final WorkerAccessContext newContext) {
    final Job nextState;
    final WorkerAccessState currentState = WorkerAccessState.valueOf(job.getState());
    switch (currentState) {
      case QUEUED:
        nextState = job.newState(WorkerAccessState.LEGAL_HOLDS_PENDING);
        break;
      case LEGAL_HOLDS_PENDING:
        nextState = job.newState(WorkerAccessState.LEGAL_HOLDS_CHECK_IN_PROGRESS);
        break;
      case LEGAL_HOLDS_CHECK_IN_PROGRESS:
        nextState = job.newState(WorkerAccessState.PENDING);
        break;
      case PENDING:
        nextState = job.newState(
            WorkerAccessState.IN_PROGRESS,
            Instant.now().plus(120, ChronoUnit.SECONDS));
        break;
      case IN_PROGRESS:
        final List<Job> pendingChildren = jobDao.getChildJobs(job.getJobKey().getJobId()).stream()
            .filter(childJob -> childJob.getJobType() != JobType.WORKER_ACCESS_ITEM
                || WorkerAccessItemState.valueOf(
                    childJob.getState()) != WorkerAccessItemState.PROCESSED)
            .collect(Collectors.toList());

        if (pendingChildren.isEmpty()) {
          nextState = job.newState(WorkerAccessState.COMPRESSION_PENDING);
        } else {
          nextState = job.newState(
              WorkerAccessState.IN_PROGRESS,
              Instant.now().plus(120, ChronoUnit.SECONDS));
        }
        break;
      case COMPRESSION_PENDING:
        nextState = job.newState(WorkerAccessState.COMPRESSION_COMPLETE);
        break;
      case COMPRESSION_COMPLETE:
        nextState = job.newState(WorkerAccessState.PROCESSED);
        break;
      default:
        throw new RuntimeException("Unknown state: " + job.getState());
    }

    return nextState;
  }

  @Override
  protected Job onException(final Job job, final WorkerAccessContext context, final Exception e) {
    final Job nextState;
    final WorkerAccessState currentState = WorkerAccessState.valueOf(job.getState());
    switch (currentState) {
      case QUEUED:
        if (e.getClass().isAssignableFrom(AccessDeniedException.class)) {
          log.error("Cannot get consent for auth in work order", e);
          nextState = job.newState(WorkerAccessState.CANCELLED, e.getLocalizedMessage());
          break;
        }
        // fall through
      default:
        log.error("Got exception for job {}", v("job", job), e);
        nextState = job;
    }
    return nextState;
  }

  @Override
  protected Job cancel(
      final Job job,
      final WorkerAccessContext context,
      final String description
  ) {
    if (!WorkerAccessState.valueOf(job.getState()).getAttributes()
        .contains(StateAttributes.CANCELABLE)) {
      log.warn("Job {} in state {} is not cancelable", v("job", job), v("state", job.getState()));
      throw new IllegalStateException("Job not in cancleable state");
    }

    return job.newState(
        WorkerAccessState.CANCELLED,
        Instant.now(),
        description);
  }
}
