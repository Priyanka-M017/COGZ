package com.intuit.dgorchworkerapp.data.models;

/**
 * Interface for job context objects. All contexts should have an id.
 */
public interface JobContext {
  String getId();

  <T extends JobContext> T withId(String id);
}
